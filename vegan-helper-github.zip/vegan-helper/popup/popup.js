'use strict';

const CACHE_KEY = 'vh-products-v1';
const DEFAULTS = { enabled: true, hideNot: false, hideUnsure: false };

async function init() {
  const s = await chrome.storage.sync.get(Object.keys(DEFAULTS));
  for (const [k, def] of Object.entries(DEFAULTS)) {
    const box = document.getElementById(k);
    box.checked = typeof s[k] === 'boolean' ? s[k] : def;
    box.addEventListener('change', () => chrome.storage.sync.set({ [k]: box.checked }));
  }

  const c = await chrome.storage.local.get(CACHE_KEY);
  const n = Object.keys(c[CACHE_KEY] || {}).length;
  document.getElementById('count').textContent =
    n ? `${n} product${n === 1 ? '' : 's'} remembered, so they load instantly next time.` : 'No products checked yet.';

  document.getElementById('recheck').addEventListener('click', async () => {
    await chrome.storage.local.remove(CACHE_KEY);
    document.getElementById('count').textContent = 'Cleared. Products will be checked again.';
  });
}

init();
