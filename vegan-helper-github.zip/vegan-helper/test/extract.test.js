'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const X = require('../src/extract.js');

test('Ocado-style product details', () => {
  const f = X.factsFromJson({
    product: { retailerProductId: '123', name: 'Mjölkchoklad' },
    bopData: { fields: [{ title: 'Ingredienser', content: '<p>Socker, <b>MJÖLK</b>pulver &amp; kakao</p>' }, { title: 'Förvaring', content: 'Torrt' }], ean: '7310000000123' }
  });
  assert.equal(f.ingredients, 'Socker, MJÖLKpulver & kakao');
  assert.equal(f.ean, '7310000000123');
  assert.equal(f.name, 'Mjölkchoklad');
});

test('ICA category path, ignoring similar products', () => {
  const f = X.factsFromJson({ product: { name: 'Bacon', categoryPath: ['Kött, Chark & Fågel', 'Matchark'] }, similarProducts: [{ categoryPath: ['Frukt & Grönt'] }] });
  assert.deepEqual(f.category, ['Kött, Chark & Fågel', 'Matchark']);
});

test('ingredients as a plain key', () => {
  const f = X.factsFromJson({ item: { ingredients: 'Ingredienser: Vatten, havre.' } });
  assert.equal(f.ingredients, 'Vatten, havre.');
});

test('vegan claims in filters or related products are ignored', () => {
  const f = X.factsFromJson({ product: { name: 'Kex' }, filters: [{ name: 'Vegansk' }], related: [{ attributes: ['Vegan'] }] });
  assert.equal(f.claimVegan, false);
  assert.equal(X.factsFromJson({ product: { attributes: [{ name: 'Vegansk' }] } }).claimVegan, true);
});

test('embedded page state', () => {
  const html = `<html><script>window.__INITIAL_STATE__ = {"product":{"details":[{"title":"Ingredienser","content":"Havregryn, smör"}]}};</script></html>`;
  assert.equal(X.factsFromHtml(html).ingredients, 'Havregryn, smör');
});

test('plain text fallback stops at the next section', () => {
  const html = '<div><h2>Ingredienser</h2><p>Vatten, salt.</p><h2>Näringsvärde</h2><p>Energi 0 kcal</p></div>';
  assert.equal(X.factsFromHtml(html).ingredients, 'Vatten, salt.');
});

test('handla.ica.se product page', () => {
  const html = '<h1 class="x">Ägg Frigående M 15-p ICA</h1><div class="product-detail"><h2 class="text-xl font-bold mb-1">Ingredienser</h2><p class="break-words">ÄGG</p></div><div class="product-detail"><h2>Näringsdeklaration</h2><p>Energi</p></div>';
  const f = X.factsFromHtml(html);
  assert.equal(f.ingredients, 'ÄGG');
  assert.equal(f.name, 'Ägg Frigående M 15-p ICA');
  assert.equal(X.productKeyFromHref('/produkt/1203222', 'https://handla.ica.se/'), '1203222');
});

test('Mathem product page', () => {
  const html = `<script type="application/ld+json">{"@context":"https://schema.org","@type":"Product","name":"Mjölkchoklad","brand":"Marabou"}</script>
  <script type="application/ld+json">{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Hem","item":"https://www.mathem.se/se/"},{"@type":"ListItem","position":2,"name":"Alla varor","item":"https://www.mathem.se/se/products/"},{"@type":"ListItem","position":3,"name":"Glass, godis &amp; snacks","item":"x"},{"@type":"ListItem","position":4,"name":"Choklad","item":"y"}]}</script>
  <div class="k-grid k-pt-3 k-pb-6"><div class="k-grid-span-12 lg:k-grid-span-4 k-column"><span class="k-text-style k-text-style--body-m k-text--weight-bold">Ingredienser</span></div><div class="k-grid-span-12 lg:k-grid-span-8 k-column"><span class="k-text-style k-text-color--subdued"><span>Socker,<!-- --> </span><span>kakaosmör,<!-- --> </span><span>vasslepulver<!-- --> </span>(<strong role="emphasis" class="k-text--weight-bold">MJÖLK</strong>), <span>arom.</span></span></div></div><div class="k-grid"><div><span class="k-text--weight-bold">Allergener</span></div><div><p>mjölk</p></div></div>`;
  const f = X.factsFromHtml(html);
  assert.equal(f.ingredients, 'Socker, kakaosmör, vasslepulver (MJÖLK), arom.');
  assert.equal(f.brand, 'Marabou');
  assert.deepEqual(f.category, ['Glass, godis & snacks', 'Choklad']);
  assert.equal(X.productKeyFromHref('/se/products/66111-marabou-mjolkchoklad/', 'https://www.mathem.se/'), '66111');
});

test('product keys', () => {
  const base = 'https://handlaprivatkund.ica.se/';
  assert.equal(X.productKeyFromHref('/stores/1004599/products/mjolkchoklad/2096880', base), '2096880');
  assert.equal(X.productKeyFromHref('/stores/1004599/products/2096880/details', base), '2096880');
  assert.equal(X.productKeyFromHref('/stores/1004599/search?q=x', base), null);
});

test('Willys / Hemköp (Axfood) product data', () => {
  const f = X.factsFromJson({
    name: 'Mjölkchoklad Chokladkaka', manufacturer: 'Marabou', ean: '7622202238475', labels: [],
    breadCrumbs: [{ name: 'Alla varor' }, { name: 'Glass, godis & snacks' }, { name: 'Choklad' }],
    ingredients: 'Ingredienser: Socker, kakaosmör, kakaomassa, vasslepulver (MJÖLK), SKUMMJÖLKSPULVER.'
  });
  assert.equal(f.ingredients, 'Socker, kakaosmör, kakaomassa, vasslepulver (MJÖLK), SKUMMJÖLKSPULVER.');
  assert.equal(f.brand, 'Marabou');
  assert.deepEqual(f.category, ['Glass, godis & snacks', 'Choklad']);
  assert.equal(X.productKeyFromHref('/produkt/Mjolkchoklad-Chokladkaka-101773952_ST', 'https://www.willys.se/'), '101773952_ST');
});

test('Coop structured product data and links', () => {
  const f = X.factsFromJson({ '@type': 'Product', name: 'Mjölkchoklad', brand: { '@type': 'Brand', name: 'Marabou' },
    additionalProperty: [{ '@type': 'PropertyValue', name: 'Protein', value: '4.6' }, { '@type': 'PropertyValue', name: 'Ingredienser', value: 'Socker, kakaosmör, vasslepulver (MJÖLK).' }] });
  assert.equal(f.ingredients, 'Socker, kakaosmör, vasslepulver (MJÖLK).');
  assert.equal(f.brand, 'Marabou');
  assert.equal(X.productKeyFromHref('/handla/varor/godis-glass-snacks/choklad/ljusa-chokladkakor/mjolkchoklad-7622202238475', 'https://www.coop.se/'), '7622202238475');
  const { siteFor } = require('../src/sites.js');
  const coop = siteFor('www.coop.se');
  assert.ok(coop.productLink.test('/handla/varor/godis-glass-snacks/choklad/ljusa-chokladkakor/mjolkchoklad-7622202238475'));
  assert.ok(!coop.productLink.test('/handla/varor/godis-glass-snacks/choklad'), 'category pages are not products');
  assert.deepEqual(coop.categoryFromHref('/handla/varor/frukt-gronsaker/frukt/bananer-7310000000001'), ['Frukt & grönsaker']);
  assert.deepEqual(coop.categoryFromHref('/handla/varor/hushall/disk/diskmedel-7310000000002'), ['Hushåll']);
  const willys = siteFor('www.willys.se');
  assert.ok(willys.productLink.test('/produkt/Mjolkchoklad-Chokladkaka-101773952_ST'));
  assert.equal(willys.apiUrls(null, '101773952_ST')[0], '/axfood/rest/p/101773952_ST');
});

test('Mathem marks vegan products in its page data', () => {
  const page = 'self.__next_f.push([1,"{\\"id\\":1663,\\"name\\":\\"Tortillas Medium 8-p\\",\\"grossPrice\\":\\"14.95\\",\\"clientClassifiers\\":[{\\"name\\":\\"Veganskt\\",\\"imageUrl\\":\\"https://www.mathem.se/static/products/img/classifier_icons/vegan.c0a8.png\\",\\"description\\":\\"Varan är vegansk\\"}]},{\\"id\\":257,\\"name\\":\\"Ansjovis\\",\\"clientClassifiers\\":[{\\"name\\":\\"Svensk flagga\\"}]}"])';
  const ids = X.veganMarkedIds(page);
  assert.ok(ids.has('1663'));
  assert.ok(!ids.has('257'));
  assert.equal(X.factsFromHtml(page, '1663').claimVegan, true);
  assert.equal(X.factsFromHtml(page, '257').claimVegan, false);
});

test('ICA product description is kept', () => {
  const f = X.factsFromJson({ product: { name: 'Tortilla' }, bopData: { detailedDescription: 'Mjuka tortillas.<br><br>Lämplig även för vegan och vegetarisk matlagning.', fields: [{ title: 'ingredients', content: 'Vetemjöl, E471.' }] } });
  assert.match(f.description, /Lämplig även för vegan/);
});
