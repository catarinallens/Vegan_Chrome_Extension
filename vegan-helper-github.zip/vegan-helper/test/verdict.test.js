'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { classifyIngredients, classifyProduct } = require('../src/verdict.js');

const cases = [
  // [label, ingredients, expected status, a reason that should be mentioned]
  ['milk chocolate', 'Socker, kakaosmör, HELMJÖLKSPULVER, kakaomassa, SÖTVASSLEPULVER (MJÖLK), emulgeringsmedel (sojalecitin), arom.', 'not', 'helmjölkspulver'],
  ['dark chocolate with traces', 'Kakaomassa, socker, kakaosmör, emulgeringsmedel (solroslecitin), vanilj. Kan innehålla spår av mjölk och hasselnötter.', 'vegan'],
  ['oat drink', 'Vatten, havre 10%, rapsolja, kalciumkarbonat, salt, vitaminer (D2, riboflavin, B12).', 'vegan'],
  ['coconut milk', 'Kokosmjölk (kokosnötsextrakt 60%, vatten), förtjockningsmedel (guarkärnmjöl).', 'vegan'],
  ['gummy bears', 'Glukossirap, socker, GELATIN, druvsocker, syra (citronsyra), färgämne (E120), aromer.', 'not', 'gelatin'],
  ['red E120 only', 'Socker, vatten, färgämne E 120.', 'not', 'E120 (karmin)'],
  ['crisps with E471', 'Potatis, solrosolja, salt, emulgeringsmedel (E471).', 'unsure', 'E471'],
  ['mono-diglycerides', 'Vetemjöl, vatten, mono- och diglycerider av fettsyror, jäst.', 'unsure', 'mono- och diglycerider'],
  ['roasted peanuts (ost inside rostade)', 'Rostade jordnötter, salt.', 'vegan'],
  ['peanut butter', 'Jordnötter 99%, salt.', 'vegan'],
  ['cocoa + shea butter lotion', 'Aqua, cocoa butter, shea butter, glycerin.', 'vegan'],
  ['cheese sauce', 'Vatten, riven ost (MJÖLK), vetemjöl, smör.', 'not', 'ost'],
  ['vegan cheese', 'Vatten, kokosolja, modifierad stärkelse, salt, vegansk ost-arom, olivextrakt.', 'vegan'],
  ['butter flavouring', 'Vetemjöl, rapsolja, socker, smörarom, salt.', 'unsure', 'smörarom'],
  ['eggs', 'Vetemjöl, socker, helägg, rapsolja.', 'not', 'helägg'],
  ['egg pasta', 'Durumvete, ÄGG 20%.', 'not', 'ägg'],
  ['aubergine', 'Äggplanta, tomat, olivolja, vitlök.', 'vegan'],
  ['lactic acid', 'Kål, salt, mjölksyrabakterier, mjölksyra.', 'vegan'],
  ['lactose-free milk', 'Laktosfri mjölk, laktasenzym.', 'not', 'mjölk'],
  ['chicken stock', 'Vatten, salt, hönsbuljong, socker.', 'not', 'hönsbuljong'],
  ['vegetable stock', 'Salt, grönsaksbuljong, jästextrakt, socker.', 'vegan'],
  ['honey', 'Havregryn, socker, HONUNG 4%.', 'not', 'honung'],
  ['salmon', 'Lax (Salmo salar) 98%, salt.', 'not', 'lax'],
  ['prawns', 'Räkor, vatten, salt.', 'not', 'räkor'],
  ['vegan "chicken"', 'Vatten, ärtprotein, rapsolja, vegokyckling-krydda, salt.', 'vegan'],
  ['English cookie', 'Wheat flour, sugar, butter, eggs, salt.', 'not', 'butter'],
  ['English vegan', 'Water, oats, rapeseed oil, sea salt, coconut milk.', 'vegan'],
  ['hemp seeds (ham inside hampa)', 'Skalade hampafrön.', 'vegan'],
  ['vitamin D3', 'Vatten, soja, socker, vitamin D3, B12.', 'unsure', 'vitamin D3'],
  ['algae omega-3', 'Rapsolja, omega-3 från alger, vitamin E.', 'vegan'],
  ['whey', 'Vasslepulver (MJÖLK), kakao, sötningsmedel.', 'not', 'vasslepulver'],
  ['bacon chips', 'Potatis, solrosolja, baconarom, salt.', 'unsure', 'baconarom'],
  ['plain pasta', 'Durumvetemjöl, vatten.', 'vegan'],
  ['ice cream', 'Grädde, socker, skummjölkspulver, äggula, vanilj.', 'not', 'grädde'],
  ['oat cream', 'Vatten, havre, rapsolja, havregrädde, salt.', 'vegan'],
  ['shellac glaze', 'Socker, kakao, ytbehandlingsmedel (E904).', 'not', 'E904 (schellack)'],
  ['rum raisins', 'Russin, rom, socker.', 'unsure', 'rom (rum or fish roe)'],
  ['real ICA, three languages', 'Ingredienser: glukossirap, socker, fullhärdat vegetabiliskt fett (kokos), helMJÖLKSpulver/sødMÆLKSpulver/helMELKpulver, kakaosmör, vasslepulver (av MJÖLK)/vallepulver (fra MÆLK)/mysepulver (fra MELK), kakaomassa, salt, emulgeringsmedel (SOJAlecitin), aromer. KAN INNEHÅLLA NÖTTER, MANDLAR OCH SPANNMÅL SOM INNEHÅLLER GLUTEN/KAN INDEHOLDE NØDDER.', 'not', 'helmjölkspulver'],
  ['Danish/Norwegian vegan', 'Havre, vand/vann, kakaosmør, kokosmælk/kokosmelk, salt.', 'vegan'],
  ['plain egg', 'ÄGG', 'not', 'ägg'],
  ['Alpro Plantgurt (yogurt cultures)', 'Vatten, sockerarter (socker, fruktos), skalade sojabönor (8,5%), blåbär (6%), kalciumfosfat, stabiliseringsmedel (pektin), surhetsreglerande medel, arom, yoghurtkulturer (S. thermophilus, L. bulgaricus), vitaminer (B12, D2).', 'vegan'],
  ['yogurt culture in English', 'Oat base, live yoghurt cultures, salt.', 'vegan'],
  ['real yoghurt still caught', 'Yoghurt (MJÖLK), socker, blåbär.', 'not', 'yoghurt'],
  ['orange juice with pulp', 'Apelsinjuice (100%), fruktkött. Vitamin C.', 'vegan'],
  ['coconut flesh', 'Kokoskött 60%, vatten.', 'vegan'],
  ['beef still caught', 'Nötkött 95%, salt.', 'not', 'nötkött'],
  ['löjrom', 'Löjrom (Coregonus albula), salt.', 'not', 'löjrom'],
  ['Grebbestads ansjovis (sprats)', 'Skarpsill (Sprattus sprattus), vatten, salt, socker, kryddor, konserveringsmedel (natriumbensoat).', 'not', 'skarpsill'],
  ['strömming', 'Strömming 70%, vatten, ättika, socker, salt.', 'not', 'strömming'],
  ['basil is not fish', 'Tomat, basilika, olivolja, salt.', 'vegan'],
  ['sturgeon caviar', 'Störrom (Acipenser gueldenstaedtii), salt.', 'not', 'störrom'],
  ['caviar spelled in English', 'Caviar, salt.', 'not', 'caviar'],
  ['sikrom', 'Sikrom 96%, salt, konserveringsmedel (E211).', 'not', 'sikrom'],
  ['flavouring is not roe', 'Socker, vatten, citronarom, arom.', 'vegan'],
  ['empty', '', 'unknown']
];

for (const [label, ingredients, expected, reason] of cases) {
  test(label, () => {
    const v = classifyIngredients(ingredients);
    assert.equal(v.status, expected, `${label}: got ${v.status} (${[...v.reasons, ...v.unsure].join(', ')})`);
    if (reason) assert.ok([...v.reasons, ...v.unsure].includes(reason), `${label}: expected "${reason}" in ${JSON.stringify([...v.reasons, ...v.unsure])}`);
  });
}

test('may-contain is noted, not flagged', () => {
  const v = classifyIngredients('Socker, kakaomassa. Kan innehålla spår av mjölk.');
  assert.equal(v.status, 'vegan');
  assert.equal(v.mayContain, true);
});

test('single-ingredient product judged by name', () => {
  assert.equal(classifyProduct({ name: 'Kycklingfilé 900g' }).status, 'not');
  assert.equal(classifyProduct({ name: 'Bananer Ekologiska' }).status, 'vegan', 'fresh produce');
  assert.equal(classifyProduct({ name: 'Havredryck Barista' }).status, 'unknown');
});

test('shrimp is never vegan', () => {
  assert.equal(classifyIngredients('Nordhavsräkor (Pandalus borealis) 92%, salt.').status, 'not');
  assert.equal(classifyIngredients('Kallvattenräkor, vatten, salt').status, 'not');
  assert.equal(classifyIngredients('Pandalus borealis, salt').status, 'not');
  // No list: the name decides. A list with no animal words and no plant protein: unsure, never vegan.
  assert.equal(classifyProduct({ name: 'Räkor med skal 70/90 Fryst 500g ICA' }).status, 'not');
  assert.equal(classifyProduct({ name: 'Räkor med skal 70/90 Fryst 500g ICA', ingredients: 'Salt, vatten.' }).status, 'unsure');
  assert.equal(classifyProduct({ name: 'Laxfilé 4-p', ingredients: 'Salt.' }).status, 'unsure');
  // Plant-based meat with an ingredient list
  assert.equal(classifyProduct({ name: 'Chorizo 240g Farmers & Chefs', ingredients: 'Vatten, ärtprotein (18%), rapsolja, paprika, vitlök, salt, kryddor, förtjockningsmedel (metylcellulosa).' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Vegobitar Kyckling-style', ingredients: 'Vatten, sojaprotein, vetegluten, salt.' }).status, 'vegan');
  // …but plant-based look-alikes are still fine
  assert.equal(classifyProduct({ name: 'Vegokorv 300g', ingredients: 'Vatten, ärtprotein, rapsolja, salt.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Vegansk räkor-ersättning', ingredients: 'Vatten, konjak, salt.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Äggfri majonnäs', ingredients: 'Rapsolja, vatten, ärtprotein, senap.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Smörgåsgurka', ingredients: 'Gurka, vatten, ättika, socker.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Smörgåspålägg Linser & Tomat', ingredients: 'Linser, tomat, rapsolja, salt.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Laxfilé', ingredients: 'Lax.' }).status, 'not');
});

test('names alone only decide on clear-cut words', () => {
  assert.equal(classifyProduct({ name: 'Smörgåsgurka 500g' }).status, 'unknown', 'needs its ingredient list');
  assert.equal(classifyProduct({ name: 'Mjölkchoklad 200g' }).status, 'unknown', 'checked via ingredients instead');
  assert.equal(classifyProduct({ name: 'Kycklingfilé 900g' }).status, 'not');
});

test('fresh produce without an ingredient list', () => {
  const vegan = (name, category) => classifyProduct({ name, category }).status;
  assert.equal(vegan('Babyplommontomater 500g Klass 1 ICA'), 'vegan');
  assert.equal(vegan('Fast potatis 1,2kg Klass 1 ICA'), 'vegan');
  assert.equal(vegan('Champinjon 250g Klass 1 ICA'), 'vegan');
  assert.equal(vegan('Sötpotatis ca 500g Klass 1'), 'vegan');
  assert.equal(vegan('Ostronskivling 150g'), 'vegan');
  assert.equal(vegan('Bananer Ekologiska'), 'vegan');
  assert.equal(vegan('Något grönt', ['Frukt & Grönt', 'Grönsaker']), 'vegan');
  assert.equal(vegan('Potatisgratäng 400g'), 'unknown', 'a dish needs its ingredient list');
  assert.equal(vegan('Kycklingfilé 900g'), 'not');
  assert.equal(classifyProduct({ name: 'Potatis', ingredients: 'Potatis, grädde' }).status, 'not', 'ingredients win');
});

test('non-food without an ingredient list gets no badge', () => {
  assert.equal(classifyProduct({ name: 'Mugg Best Person', category: ['Hem & Inredning', 'Muggar'] }).status, 'skip');
  assert.equal(classifyProduct({ name: 'Servetter 72st', category: ['Städ, Tvätt & Papper'] }).status, 'skip');
  assert.equal(classifyProduct({ name: 'Handkräm', category: ['Skönhet'], ingredients: 'Aqua, glycerin, lanolin' }).status, 'not', 'still checked when there is a list');
});

test('"Vegan" in the name counts as the label', () => {
  const v = classifyProduct({ name: 'Adventskalender Godis Vegan 373g Hulten', ingredients: 'Socker, glukossirap, majsstärkelse, emulgeringsmedel (E470, E471), arom.' });
  assert.equal(v.status, 'vegan');
  assert.equal(classifyProduct({ name: 'Vegansk Bolognese 400g ICA', ingredients: 'Tomat, ärtprotein, vitamin D3.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Ej vegansk pastej', ingredients: 'Vatten, E471.' }).status, 'unsure', '"not vegan" isn\'t a claim');
  // A vegan name with a clear animal ingredient is flagged for a look, not trusted blindly
  assert.equal(classifyProduct({ name: 'Vegan kakor', ingredients: 'Vetemjöl, socker, smör.' }).status, 'unsure');
});

test('all-plant brands', () => {
  assert.equal(classifyProduct({ name: 'Matlagningsprodukt Havre 5dl Oddlygood®', ingredients: 'Havrebas (vatten, havre 9%), rapsolja, emulgeringsmedel (E472e), salt.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'iMat Havre 2,5dl', brand: 'Oatly', ingredients: 'Havrebas, rapsolja, E471, D3-vitamin.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Kakor', brand: 'Oatly', ingredients: 'Mjöl, smör.' }).status, 'unsure', 'clear animal ingredient still flagged');
  assert.equal(classifyProduct({ name: 'Quorn Bitar', ingredients: 'Mykoprotein, äggvita.' }).status, 'not', 'mixed brands not trusted');
});

test('vegan label lifts unsure to vegan', () => {
  const v = classifyProduct({ ingredients: 'Vatten, soja, vitamin D3.', claimVegan: true });
  assert.equal(v.status, 'vegan');
});

test('vegan label vs animal word becomes unsure, not a guess', () => {
  const v = classifyProduct({ ingredients: 'Vatten, mjölk.', claimVegan: true });
  assert.equal(v.status, 'unsure');
  assert.equal(v.conflict, true);
});

test('Open Food Facts fallback', () => {
  assert.equal(classifyProduct({ offTags: ['en:non-vegan', 'en:vegetarian'] }).status, 'not');
  assert.equal(classifyProduct({ offTags: ['en:vegan'] }).status, 'vegan');
  assert.equal(classifyProduct({ offIngredients: 'Socker, gelatin.' }).status, 'not');
});

test('Coop categories decide produce and non-food', () => {
  assert.equal(classifyProduct({ name: 'Bananer Fairtrade', category: ['Frukt & grönsaker'] }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Diskmedel Citron', category: ['Hushåll'] }).status, 'skip');
});

test('fish and meat shelves are never called vegan by accident', () => {
  const fish = ['Fisk & skaldjur', 'Sill, ansjovis & kaviar'];
  assert.equal(classifyProduct({ name: 'Ansjovis Original 55g Grebbestads', category: fish, ingredients: 'Vatten, salt, socker, kryddor.' }).status, 'not');
  assert.equal(classifyProduct({ name: 'Löjrom Fryst', category: ['Fisk & skaldjur', 'Kaviar & rom'], ingredients: 'Salt.' }).status, 'not');
  assert.equal(classifyProduct({ name: 'Något utan lista', category: ['Kött, fågel & chark'] }).status, 'not');
  // …but plant-based products on those shelves still pass
  assert.equal(classifyProduct({ name: 'Vegansk fiskpinne', category: fish, ingredients: 'Vete, rapsolja, salt.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Färs', category: ['Kött, fågel & chark', 'Vegetariska alternativ'], ingredients: 'Vatten, salt.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Bitar', category: ['Kött, fågel & chark'], ingredients: 'Vatten, ärtprotein, rapsolja.' }).status, 'vegan');
  // Dairy is left alone: oat drinks live there
  assert.equal(classifyProduct({ name: 'Havredryck 1l ICA', category: ['Mejeri & Ost', 'Mjölk'], ingredients: 'Vatten, havre 10%, rapsolja, salt.' }).status, 'vegan');
});

test('caviar by name alone', () => {
  assert.equal(classifyProduct({ name: 'Caviar Oscietra Royal Ars Italica' }).status, 'not');
});

test('seaweed caviar is vegan', () => {
  const roeShelf = ['Fisk & skaldjur', 'Kaviar & rom'];
  assert.equal(classifyIngredients('Tång (Ascophyllum nodosum) 60%, vatten, salt, citronsyra, förtjockningsmedel (xantangummi).').status, 'vegan');
  assert.equal(classifyProduct({ name: 'Tångkaviar Svart 100g', category: roeShelf, ingredients: 'Sjögräs 55%, vatten, salt, alginat.' }).status, 'vegan');
  assert.notEqual(classifyProduct({ name: 'Tångkaviar Svart 100g', category: roeShelf }).status, 'not', 'never flagged as fish just for its shelf');
  assert.equal(classifyProduct({ name: 'Svart Kaviar', brand: 'Cavi-art', category: roeShelf, ingredients: 'Vatten, salt.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Caviar Oscietra Royal', category: roeShelf, ingredients: 'Störrom, salt.' }).status, 'not', 'real caviar still caught');
});

test('meat cuts', () => {
  assert.equal(classifyProduct({ name: 'Rostbiffstek ca 1250g Scan' }).status, 'not');
  assert.equal(classifyProduct({ name: 'Rostbiffstek', ingredients: 'Sverige' }).status, 'unsure', 'never vegan, even if the wrong text were read');
  assert.equal(classifyProduct({ name: 'Rostbiffstek', category: ['Kött, chark & fågel', 'Nöt'], ingredients: 'Sverige' }).status, 'not');
  assert.equal(classifyProduct({ name: 'Sojabiff 300g', ingredients: 'Sojaprotein, vatten, salt.' }).status, 'vegan');
});

test('a (mis)read vegan label never overrides meat', () => {
  assert.equal(classifyProduct({ name: 'Ölkorv Chili 80g', claimVegan: true, ingredients: 'Griskött, nötkött, salt, kryddor, chili.' }).status, 'not');
  assert.equal(classifyProduct({ name: 'Kakor', claimVegan: true, ingredients: 'Vetemjöl, socker, smör.' }).status, 'unsure', 'weaker clash stays unsure');
});

test('Danish/Norwegian "free from" and "for vegans"', () => {
  const annas = 'Hvetemjöl, socker, rapsolja, sirap, kryddor, bakpulver, salt. Laktosefri for veganer.';
  assert.equal(classifyIngredients(annas).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Pepparkakor 300g Annas', ingredients: annas }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Kex', ingredients: 'Vetemjöl, socker, E471. Egnet for veganere.' }).status, 'vegan', 'the phrase lifts unsure');
  assert.equal(classifyIngredients('Mjölk, laktosfri.').status, 'not', 'real milk still caught');
  assert.equal(classifyProduct({ name: 'Kex', ingredients: 'Vetemjöl, smör. Ikke egnet for veganere.' }).status, 'not');
});

test("Anna's pepparkakor, real ICA text", () => {
  const ing = 'INGREDIENSER: VETEMJÖL/HVETEMEL/HVEDEMEL, socker/sukker, vegetabiliska/vegetabilske oljor/oljer/olier (palm/palme*, raps, kokos), sirap/sirup, bakpulver/bakepulver/bagepulver (natriumbikarbonat), kanel, salt, ingefära/ingefær 0.3%, kryddnejlika/kryddernellik/kryddernellike. Laktosfri och lämplig för veganer / Laktosefri og egnet for veganere / Laktosefri og velegnet til veganere.';
  assert.equal(classifyProduct({ name: 'Pepparkakor 300g Annas', ingredients: ing }).status, 'vegan');
});

test('additives the list says are plant-derived', () => {
  const korvbrod = 'Ingredienser: VETEMJÖL*, vatten*, invertsocker*, rapsolja*, jäst*, VETEGLUTEN, salt, fermenterat vetemjöl, maltmjöl av KORN, vegetabiliskt emulgeringsmedel (E471), mjölbehandlingsmedel (E300). Kan innehålla spår av sesamfrö.';
  assert.equal(classifyIngredients(korvbrod).status, 'vegan');
  assert.equal(classifyIngredients('Mjöl, vegetabiliska mono- och diglycerider av fettsyror, salt.').status, 'vegan');
  assert.equal(classifyIngredients('Mjöl, emulgeringsmedel (E471 av vegetabiliskt ursprung), salt.').status, 'vegan');
  assert.equal(classifyIngredients('Vatten, havre, vitamin D3 (från lav).').status, 'vegan');
  // Without the word, still unsure — and "vegetabiliskt fett" earlier in the list doesn't count
  assert.equal(classifyIngredients('Mjöl, vegetabiliskt fett (palm), salt, emulgeringsmedel (E471).').status, 'unsure');
});

test('look-alike names that are not animal', () => {
  const hono = 'VETEmjöl, vatten, socker, siktat RÅGmjöl, rapsolja, fullkornsRÅGmjöl, fullkornsVETEmjöl, skållat VETEmjöl, vegetabiliskt emulgeringsmedel mono- och diglycerider av fettsyror (solros, raps), bakpulver (hjorthornssalt), VETEgluten, malt av KORN, jäst, salt, mjölbehandlingsmedel (askorbinsyra).';
  assert.equal(classifyIngredients(hono).status, 'vegan');
  assert.equal(classifyIngredients('Socker, hjortron 40%, vatten, pektin.').status, 'vegan');
  assert.equal(classifyIngredients('Lammsallad, ruccola, spenat.').status, 'vegan');
  assert.equal(classifyIngredients('Blodapelsinjuice 100%.').status, 'vegan');
  assert.equal(classifyIngredients('Hjortkött 90%, salt.').status, 'not', 'real deer still caught');
});

test('rom: rum in sweets, roe in fish', () => {
  const punsch = 'Socker, kakaomassa, kakaosmör, glukossirap, vatten, arrak, rom, emulgeringsmedel (sojalecitin), arom.';
  assert.equal(classifyProduct({ name: 'Punchpokal', ingredients: punsch, category: ['Godis, glass & snacks'] }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Punchpokal', ingredients: punsch }).status, 'vegan', 'sweet words decide even without a category');
  assert.equal(classifyProduct({ name: 'Romsås till fisk', ingredients: 'Majonnäs-bas (rapsolja, vatten), rom, dill, salt.', category: ['Fisk & skaldjur'] }).status, 'not');
  assert.equal(classifyProduct({ name: 'Smörgåstårta-mix', ingredients: 'Rom, salt.' }).status, 'unsure', 'no context: still unsure');
});

test('plant butters in any spelling', () => {
  const cups = 'Ingredienser: JORDNÖTTER/JORDNØDDER/PEANØTTER*(30 %), kokossocker/kokossukker*, kakaomassa/kakaomasse*, kakaosmör/kakao smør*, sheasmör/sheasmør*, kokosgrädde/kokoscreme/kokoskrem*, kokosmjöl/kokosmel*, emulgeringsmedel/emulgator(solroslecitin/solsikke lecithin/solsikkelecitin*), salt. *Ekologisk ingrediens. Kan innehålla/inneholde spår/spor av/af nötter/nødder/nøtter och/og sesamfrön/sesamfrø.';
  assert.equal(classifyIngredients(cups).status, 'vegan');
  assert.equal(classifyIngredients('Mjöl, kakao smör, socker.').status, 'vegan');
  assert.equal(classifyIngredients('Mjöl, smør, socker.').status, 'not', 'real butter still caught');
});

test('non-food that is usually animal-derived', () => {
  assert.equal(classifyProduct({ name: 'Tändstickor Hushållsask 240st', category: ['Fritid', 'Grill'] }).status, 'not');
  assert.equal(classifyProduct({ name: 'Bivaxljus 2-p', category: ['Hem & inredning'] }).status, 'not');
  assert.equal(classifyProduct({ name: 'Stearinljus 10-p', category: ['Hem & inredning'] }).status, 'unsure');
  assert.equal(classifyProduct({ name: 'Rapsvaxljus 10-p', category: ['Hem & inredning'] }).status, 'skip', 'plant wax: no badge');
  assert.equal(classifyProduct({ name: 'Raps stearinljus', category: ['Hem & inredning'] }).status, 'skip');
  assert.equal(classifyProduct({ name: 'Diskmedel Citron', category: ['Hushåll'] }).status, 'skip');
  assert.equal(classifyProduct({ name: 'Vattendunk 10l', category: ['Fritid'] }).status, 'skip', 'dunk is a jug, not down');
});

test('food names that sound like textiles', () => {
  assert.notEqual(classifyProduct({ name: 'Mocka Kaffe Hela bönor 450g', category: ['Dryck', 'Kaffe'] }).status, 'not');
  assert.equal(classifyProduct({ name: 'Ullstrumpor 2-p', category: ['Kläder & accessoarer'] }).status, 'not');
});

test('"suitable for vegans" in the description', () => {
  const ing = 'VETEMJÖL (72%), vatten, rapsolja, fuktighetsbevarande medel (E422), salt, emulgeringsmedel (E471), bakpulver (natriumkarbonater), surhetsreglerande medel (citronsyra), sockerbetsfiber.';
  const desc = 'Super soft medium • Utan tillsatt socker • Tortillabröd går utmärkt att frysa • Lämplig även för vegan och vegetarisk matlagning.';
  assert.equal(classifyProduct({ name: 'Tortilla Original Medium 8-p 320g Santa Maria', ingredients: ing }).status, 'unsure');
  assert.equal(classifyProduct({ name: 'Tortilla Original Medium 8-p 320g Santa Maria', ingredients: ing, description: desc }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Kakor', ingredients: 'Mjöl, E471.', description: 'Passar perfekt för veganer.' }).status, 'vegan');
  assert.equal(classifyProduct({ name: 'Smörkakor', ingredients: 'Mjöl, smör.', description: 'Ej lämplig för veganer.' }).status, 'not');
});
