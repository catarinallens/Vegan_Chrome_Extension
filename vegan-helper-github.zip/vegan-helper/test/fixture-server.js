'use strict';
// A small fake shop shaped like ICA's online store (Ocado platform URLs),
// used to test the extension end to end.
const http = require('http');

const STORE = '1004599';
const P = (id, slug, name, price, ingredients, extra = {}) => ({ id, slug, name, price, ingredients, ...extra });

const PRODUCTS = [
  P('1001', 'ica-mjolkchoklad', 'Mjölkchoklad 200g', '29,90 kr', 'Socker, kakaosmör, HELMJÖLKSPULVER, kakaomassa, SÖTVASSLEPULVER (MJÖLK), emulgeringsmedel (sojalecitin), arom.'),
  P('1002', 'mork-choklad-70', 'Mörk choklad 70% 100g', '24,90 kr', 'Kakaomassa, socker, kakaosmör, emulgeringsmedel (solroslecitin), vanilj. Kan innehålla spår av mjölk.'),
  P('1003', 'havre-choklad', 'Havremjölkchoklad 100g', '32,90 kr', 'Socker, kakaosmör, havrepulver 20%, kakaomassa, emulgeringsmedel (solroslecitin).', { vegan: true }),
  P('1004', 'chokladgodis-geleer', 'Chokladgodis & gelé 150g', '19,90 kr', 'Glukossirap, socker, GELATIN, kakao, färgämne (E120).'),
  P('1005', 'chokladkex', 'Chokladkex 175g', '21,50 kr', 'Vetemjöl, socker, palmfett, kakao, emulgeringsmedel (E471), salt.'),
  P('1006', 'chokladbollar', 'Chokladbollar 6-pack', '34,90 kr', 'Havregryn, socker, SMÖR, kakao, kaffe.', { noApi: true }), // only in the page HTML
  P('1007', 'kakaonibs', 'Kakaonibs eko 200g', '49,90 kr', 'Kakaobönor*. *Ekologisk.'),
  P('1008', 'chokladmousse', 'Chokladmousse 4-p', '27,90 kr', 'GRÄDDE, socker, kakao, ÄGGULA, gelatin.'),
  P('1009', 'bananer', 'Bananer eko ca 180g', '4,50 kr', ''),
  P('1010', 'kycklingfile', 'Kycklingfilé 900g', '99,00 kr', ''),
  P('1013', 'mugg', 'Mugg Best Person', '89,00 kr', '', { noApi: true })
];
const MORE = [
  P('1011', 'chokladdryck', 'Chokladdryck havre 1l', '25,90 kr', 'Vatten, havre, socker, kakao, rapsolja, salt.'),
  P('1012', 'chokladpudding', 'Chokladpudding 500g', '23,90 kr', 'MJÖLK, socker, majsstärkelse, kakao.')
];
const ALL = [...PRODUCTS, ...MORE];
const byId = Object.fromEntries(ALL.map((p) => [p.id, p]));
const href = (p) => `/stores/${STORE}/products/${p.slug}/${p.id}`;

const CSS = `
  body { margin: 0; font-family: Arial, sans-serif; background: #fff; color: #222; }
  header { height: 64px; background: #e3000b; color: #fff; display: flex; align-items: center; gap: 24px; padding: 0 32px; }
  header a { color: #fff; }
  main { padding: 24px 32px; }
  ul.grid { list-style: none; padding: 0; margin: 0; display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
  .tile { border: 1px solid #ddd; border-radius: 8px; padding: 12px; display: flex; flex-direction: column; gap: 6px; }
  .img { height: 120px; background: #f1ece4; border-radius: 6px; display: block; }
  .tile a { color: #222; text-decoration: none; font-weight: bold; }
  .cart-row { display: flex; gap: 16px; align-items: center; border-bottom: 1px solid #ddd; padding: 12px 0; }
  .cart-row .img { width: 64px; height: 64px; }
`;

function tile(p) {
  return `<li class="tile" data-test="fop-wrapper">
    <a href="${href(p)}" class="img" aria-label="${p.name}"></a>
    <a href="${href(p)}"><h3 style="margin:0;font-size:15px">${p.name}</h3></a>
    <span>${p.price}</span>
    <button type="button">Köp</button>
  </li>`;
}

function page(title, body, script = '') {
  return `<!doctype html><html lang="sv"><head><meta charset="utf-8"><title>${title}</title><style>${CSS}</style></head>
  <body><header><strong>ICA (test)</strong><a href="/stores/${STORE}/search?q=choklad">Sök</a><a href="/stores/${STORE}/cart">Varukorg</a></header>
  <main>${body}</main>${script}</body></html>`;
}

const hits = { blocked: 0, bop: {} };
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const send = (code, type, body) => { res.writeHead(code, { 'content-type': type }); res.end(body); };

  if (url.pathname === '/__hits') return send(200, 'application/json', JSON.stringify(hits));

  // A page whose products trip the shop's bot protection
  const BLOCKED = ['2001', '2002', '2003'].map((id) => P(id, 'blockerad-' + id, 'Blockerad produkt ' + id, '10,00 kr', ''));
  if (url.pathname === `/stores/${STORE}/blocked`) {
    return send(200, 'text/html', page('Blockerad', `<ul class="grid">${BLOCKED.map(tile).join('')}</ul>`));
  }
  if (url.pathname === `/stores/${STORE}/api/webproductpagews/v5/products/bop` && /^2/.test(url.searchParams.get('retailerProductId') || '')) {
    hits.blocked++;
    return send(202, 'text/html', '<html><title>Human Verification</title></html>');
  }

  // Product details API (Ocado-style "bop")
  if (url.pathname === `/stores/${STORE}/api/webproductpagews/v5/products/bop`) {
    const p = byId[url.searchParams.get('retailerProductId')];
    hits.bop[url.searchParams.get('retailerProductId')] = (hits.bop[url.searchParams.get('retailerProductId')] || 0) + 1;
    if (!p || p.noApi) return send(404, 'application/json', '{"error":"not found"}');
    const fields = [];
    if (p.ingredients) fields.push({ title: 'Ingredienser', content: `<p>${p.ingredients}</p>` });
    fields.push({ title: 'Förvaring', content: '<p>Förvaras torrt.</p>' });
    return send(200, 'application/json', JSON.stringify({
      product: { retailerProductId: p.id, name: p.name, brand: 'Testmärke', attributes: p.vegan ? [{ name: 'Vegansk' }] : [] },
      bopData: { fields, ean: '73' + p.id.padStart(11, '0') }
    }));
  }

  // The shop's own listing data (what the real page loads for itself)
  if (url.pathname === `/stores/${STORE}/api/webproductpagews/v5/product-pages`) {
    const cat = { '1009': ['Frukt & Grönt', 'Frukt'], '1013': ['Hem & Inredning', 'Muggar'] };
    return send(200, 'application/json', JSON.stringify({ productGroups: [{ decoratedProducts: PRODUCTS.map((p) => ({ retailerProductId: p.id, name: p.name, brand: 'Testmärke', categoryPath: cat[p.id] || ['Godis'] })) }] }));
  }

  // Search results; more products "load" as you scroll
  if (url.pathname === `/stores/${STORE}/search`) {
    const script = `<script>fetch('/stores/${STORE}/api/webproductpagews/v5/product-pages?tag=web');</script><script>setTimeout(() => {
      document.querySelector('ul.grid').insertAdjacentHTML('beforeend', ${JSON.stringify(MORE.map(tile).join(''))});
    }, 2500);</script>`;
    return send(200, 'text/html', page('Sök: choklad', `<h1>Sökresultat för "choklad"</h1><ul class="grid">${PRODUCTS.map(tile).join('')}</ul>`, script));
  }

  // Cart
  if (url.pathname === `/stores/${STORE}/cart`) {
    const items = ['1001', '1002', '1004', '1007'].map((id) => byId[id]);
    return send(200, 'text/html', page('Varukorg', `<h1>Varukorg</h1>${items.map((p) => `
      <div class="cart-row"><a class="img" href="${href(p)}" aria-label="${p.name}"></a>
      <a href="${href(p)}">${p.name}</a><span>${p.price}</span><button type="button">Ta bort</button></div>`).join('')}`));
  }

  // Product page: an app shell that renders the details with JS (like the real shop),
  // except 1006 which has its data embedded in the HTML.
  const m = url.pathname.match(new RegExp(`^/stores/${STORE}/products/[^/]+/(\\d+)$`));
  if (m && byId[m[1]]) {
    const p = byId[m[1]];
    const state = p.noApi ? `<script>window.__INITIAL_STATE__ = ${JSON.stringify({ product: { name: p.name, details: [{ title: 'Ingredienser', content: p.ingredients }] } })};</script>` : '';
    const render = `<script>setTimeout(() => {
      document.querySelector('#app').innerHTML = ${JSON.stringify(`<h1>${p.name}</h1><p>${p.price}</p>
        <section><h2>Ingredienser</h2><p>${p.ingredients || ''}</p></section>
        <section><h2>Förvaring</h2><p>Förvaras torrt.</p></section>
        <h3>Liknande produkter</h3><ul class="grid">${[byId['1002'], byId['1008']].map(tile).join('')}</ul>`)};
    }, 600);</script>`;
    return send(200, 'text/html', page(p.name, `<div id="app">Laddar…</div>`, state + render));
  }

  send(404, 'text/plain', 'not found');
});

if (require.main === module) server.listen(8787, () => console.log('fixture shop on http://localhost:8787'));
module.exports = { server, STORE };
