'use strict';
// Loads the real extension into Chromium and shops on the fake ICA site.
const fs = require('fs');
const path = require('path');
const os = require('os');
const assert = require('assert/strict');
const { chromium } = require('playwright');
const { server, STORE } = require('./fixture-server');

const ROOT = path.join(__dirname, '..');
const OUT = process.env.SHOTS || path.join(os.tmpdir(), 'vh-shots');
const BASE = 'http://localhost:8787';

function buildTestCopy() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vh-ext-'));
  fs.cpSync(ROOT, dir, { recursive: true, filter: (p) => !p.includes(`${path.sep}test`) && !p.includes('node_modules') && !p.endsWith('.zip') });
  const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
  manifest.content_scripts.forEach((c) => c.matches.push(`${BASE}/*`));
  manifest.host_permissions.push(`${BASE}/*`);
  fs.writeFileSync(path.join(dir, 'manifest.json'), JSON.stringify(manifest, null, 2));
  const sites = path.join(dir, 'src', 'sites.js');
  fs.writeFileSync(sites, fs.readFileSync(sites, 'utf8').replace("hosts: ['handlaprivatkund.ica.se']", "hosts: ['handlaprivatkund.ica.se', 'localhost:8787']"));
  return dir;
}

const tileInfo = (page) => page.$$eval('li.tile', (els) => els.map((el) => ({
  name: el.querySelector('h3').textContent,
  hidden: getComputedStyle(el).display === 'none',
  opacity: getComputedStyle(el.querySelector('h3').closest('a')).opacity,
  badgeOpacity: el.querySelector('.vh-badge') ? getComputedStyle(el.querySelector('.vh-badge')).opacity : null,
  badge: el.querySelector('.vh-badge')?.textContent || null
})));

const barText = (page) => page.evaluate(() => {
  const host = document.querySelector('[data-vh-ui]:not(.vh-badge)');
  return host?.shadowRoot ? host.shadowRoot.querySelector('.wrap').innerText.replace(/\s+/g, ' ').trim() : null;
});

async function waitForChecks(page, count) {
  await page.waitForFunction((n) => {
    const badges = [...document.querySelectorAll('.vh-badge')];
    return badges.length >= n && badges.every((b) => b.textContent !== 'Checking…');
  }, count, { timeout: 90000 });
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  await new Promise((r) => server.listen(8787, r));
  const ext = buildTestCopy();
  const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'vh-profile-')), {
    channel: 'chromium',
    headless: true,
    viewport: { width: 1280, height: 900 },
    args: [`--disable-extensions-except=${ext}`, `--load-extension=${ext}`]
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));

  // 1. Search results: everything visible by default, non-vegan faded and labelled
  await page.goto(`${BASE}/stores/${STORE}/search?q=choklad`);
  await waitForChecks(page, 12);
  let tiles = await tileInfo(page);
  console.table(tiles);
  const t = (name) => tiles.find((x) => x.name.startsWith(name));
  assert.ok(tiles.every((x) => !x.hidden), 'nothing hidden until the switch is on');
  const milk = t('Mjölkchoklad');
  assert.equal(milk.opacity, '0.45');
  assert.equal(milk.badgeOpacity, '1', 'badge stays readable on a faded product');
  assert.match(milk.badge, /^Not vegan · helmjölkspulver/);
  assert.match(t('Chokladbollar').badge, /^Not vegan · smör/, 'found via embedded page data');
  assert.match(t('Kycklingfilé').badge, /^Not vegan/, 'judged by name');
  assert.equal(t('Mörk choklad').badge, 'Vegan');
  assert.equal(t('Havremjölkchoklad').badge, 'Vegan');
  assert.equal(t('Kakaonibs').badge, 'Vegan');
  assert.match(t('Chokladkex').badge, /^Unsure · E471/);
  assert.equal(t('Bananer').badge, 'Vegan', 'fresh produce');
  console.log('bar:', await barText(page));
  assert.match(await barText(page), /12 checked/);
  await page.screenshot({ path: path.join(OUT, '2-search-all-labelled.png') });

  // 2. Flip the switch: non-vegan products disappear
  const host = await page.$('[data-vh-ui]:not(.vh-badge)');
  const sw = async () => (await host.evaluateHandle((h) => h.shadowRoot.querySelector('[role="switch"]'))).asElement();
  await (await sw()).click();
  await page.waitForTimeout(300);
  tiles = await tileInfo(page);
  for (const n of ['Mjölkchoklad', 'Chokladgodis', 'Chokladmousse', 'Chokladbollar', 'Kycklingfilé', 'Chokladpudding']) assert.equal(t(n).hidden, true, n);
  assert.equal(t('Mörk choklad').hidden, false);
  assert.equal(t('Chokladkex').hidden, false, 'unsure stays visible');
  assert.equal(await (await sw()).getAttribute('aria-checked'), 'true');
  console.log('bar after switch:', await barText(page));
  assert.match(await barText(page), /6 hidden · 12 checked/);
  await page.screenshot({ path: path.join(OUT, '1-search-vegan-only.png') });

  // 2b. Second switch hides the unsure ones too
  const sw2 = (await host.evaluateHandle((h) => h.shadowRoot.querySelector('[data-k="hideUnsure"]'))).asElement();
  await sw2.click();
  await page.waitForTimeout(300);
  tiles = await tileInfo(page);
  assert.equal(t('Chokladkex').hidden, true, 'unsure hidden');
  assert.match(await barText(page), /7 hidden/);
  await sw2.click();

  // 3. Products decided from the shop's own data, without asking
  const hitsNow = await (await fetch(`${BASE}/__hits`)).json();
  assert.equal(hitsNow.bop['1009'] || 0, 0, 'bananas: no request, the page said Frukt & Grönt');
  assert.equal(hitsNow.bop['1013'] || 0, 0, 'mug: no request, the page said Hem');
  tiles = await tileInfo(page);
  assert.equal(t('Bananer').badge, 'Vegan');
  assert.equal(tiles.find((x) => x.name.startsWith('Mugg')).badge, null, 'no badge on non-food');

  // 4. Product page: verdict for the product you're looking at
  await page.goto(`${BASE}/stores/${STORE}/products/ica-mjolkchoklad/1001`);
  await page.waitForFunction(() => {
    const h = document.querySelector('[data-vh-ui]:not(.vh-badge)');
    const el = h?.shadowRoot?.querySelector('.product');
    return el && !el.hidden && !/Checking/.test(el.textContent);
  }, null, { timeout: 10000 });
  console.log('product page bar:', await barText(page));
  assert.match(await barText(page), /Not vegan ?Contains helmjölkspulver, sötvasslepulver/);
  await page.screenshot({ path: path.join(OUT, '3-product-page.png') });

  // 5. Cart: nothing hidden, a summary instead
  await page.goto(`${BASE}/stores/${STORE}/cart`);
  await waitForChecks(page, 4);
  const hiddenInCart = await page.$$eval('.cart-row', (rows) => rows.filter((r) => getComputedStyle(r).display === 'none').length);
  assert.equal(hiddenInCart, 0);
  const cartBadges = await page.$$eval('.cart-row', (rows) => rows.map((r) => {
    const b = r.querySelector('.vh-badge');
    return { inline: getComputedStyle(b).position !== 'absolute', faded: [...r.children].some((c) => getComputedStyle(c).opacity !== '1') };
  }));
  assert.ok(cartBadges.every((b) => b.inline && !b.faded), 'cart badges sit next to the name, nothing faded');
  console.log('cart bar:', await barText(page));
  assert.match(await barText(page), /2 of 4 items aren't vegan/);
  await page.screenshot({ path: path.join(OUT, '4-cart.png') });

  // 6. If the shop's bot protection answers, stop asking and say so
  await page.goto(`${BASE}/stores/${STORE}/blocked`);
  await page.waitForFunction(() => {
    const h = document.querySelector('[data-vh-ui]:not(.vh-badge)');
    return /check you're human/.test(h?.shadowRoot?.querySelector('.status')?.textContent || '');
  }, null, { timeout: 15000 });
  await page.waitForTimeout(4000);
  const hits = await (await fetch(`${BASE}/__hits`)).json();
  console.log('blocked page bar:', await barText(page), '| requests after being blocked:', hits.blocked);
  assert.equal(hits.blocked, 1, 'only one request before backing off');
  const buttons = await page.evaluate(() => {
    const sr = document.querySelector('[data-vh-ui]:not(.vh-badge)').shadowRoot;
    return { check: !sr.querySelector('.check').hidden, resume: !sr.querySelector('.resume').hidden };
  });
  assert.deepEqual(buttons, { check: true, resume: true }, 'asks you to do the check');
  await page.evaluate(() => document.querySelector('[data-vh-ui]:not(.vh-badge)').shadowRoot.querySelector('.resume').click());
  await page.waitForTimeout(1500);
  const hits2 = await (await fetch(`${BASE}/__hits`)).json();
  assert.equal(hits2.blocked, 2, 'Resume tries again');

  assert.deepEqual(errors, [], 'no page errors');
  console.log('\nAll end-to-end checks passed. Screenshots in', OUT);
  await ctx.close();
  server.close();
})().catch(async (e) => {
  console.error(e);
  process.exit(1);
});
