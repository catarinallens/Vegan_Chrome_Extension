/*
 * Vegan Helper: ingredient classifier.
 * Reads an ingredient list (Swedish or English) and returns a verdict:
 *   vegan | not | unsure | unknown
 * Pure functions, no browser APIs, so it runs in the extension and in Node tests.
 */
(function (root) {
  'use strict';

  // Bump when the word lists change, so cached verdicts are recomputed.
  const VERDICT_VERSION = 3;

  // Phrases that contain an animal word but are plant-based (or not food at all).
  // Removed from the text before scanning. Longest first, so compounds win.
  const SAFE_PHRASES = [
    // Swedish plant "milks", "creams" and "butters"
    'kakaosmörsersättning', 'kakaosmör', 'sheasmör', 'shea-smör', 'jordnötssmör', 'mandelsmör',
    'cashewsmör', 'nötsmör', 'sesamsmör', 'solrosfrösmör', 'hasselnötssmör',
    'kokosmjölkspulver', 'kokosmjölk', 'havremjölk', 'sojamjölk', 'mandelmjölk', 'rismjölk',
    'cashewmjölk', 'ärtmjölk', 'hampamjölk', 'kokosgrädde', 'havregrädde', 'sojagrädde',
    'växtgrädde', 'mandelgrädde',
    // Lactic acid and cultures are not dairy
    'mjölksyrabakterier', 'mjölksyrabakteriekultur', 'mjölksyrade', 'mjölksyrad', 'mjölksyra',
    // "free from" words
    'mjölkfritt', 'mjölkfria', 'mjölkfri', 'laktosfritt', 'laktosfria', 'laktosfri',
    'äggfritt', 'äggfria', 'äggfri', 'köttfritt', 'köttfria', 'köttfri', 'köttersättning',
    'fiskfri', 'gelatinfri',
    // Fruit "meat" is pulp or flesh
    'fruktköttet', 'fruktkött', 'kokosnötkött', 'kokosköttet', 'kokoskött', 'pumpakött', 'melonkött',
    'avokadokött', 'mangokött', 'citruskött', 'apelsinkött', 'aloe vera-kött', 'jackfruktkött',
    // Other look-alikes
    // Plants and minerals whose names start with an animal word
    'hjorthornssalt', 'hjorthornsalt', 'hjortronsylt', 'hjortronen', 'hjortron', 'lammsallad',
    'blodapelsiner', 'blodapelsin', 'blodgrapefrukt', 'smörgåskrasse', 'smörgåsgurka', 'ostindisk',
    'ostronskivlingar', 'ostronskivling', 'äggplantor', 'äggplanta', 'gräddade', 'gräddad', 'gräddat',
    // Danish / Norwegian (ICA's lists are often in all three languages)
    'kakaosmør', 'sheasmør', 'kakao smør', 'kakao smör', 'shea smør', 'shea smör', 'kakao-smör', 'kakao-smør',
    'peanøttsmør', 'mandelsmør', 'kokosmælk', 'havremælk', 'sojamælk', 'mandelmælk', 'kokosmelk', 'havremelk',
    'soyamelk', 'mandelmelk', 'mælkesyre', 'melkesyre', 'mælkefri', 'melkefri', 'jordnøddesmør',
    'peanøttsmør',
    // English
    'coconut milk', 'oat milk', 'soy milk', 'soya milk', 'almond milk', 'rice milk', 'cocoa butter',
    'shea butter', 'peanut butter', 'nut butter', 'almond butter', 'cream of tartar', 'eggplant',
    'butternut', 'milk-free', 'milk free', 'dairy-free', 'dairy free', 'egg-free', 'egg free',
    'lactic acid', 'milk thistle', 'coconut cream', 'oat cream', 'soy cream'
  ].sort((a, b) => b.length - a.length);

  // Non-vegan words.
  //  any:  can appear inside a Swedish compound (helmjölkspulver, sötvasslepulver)
  //  start: must start a word (ost, not rostad)
  //  word:  must be a whole word (English; avoids "ham" in "hampa")
  const NOT_VEGAN = {
    any: [
      'mjölk', 'vassle', 'grädd', 'smör', 'kasein', 'laktos', 'honung', 'gelatin', 'kött',
      'fläsk', 'kyckling', 'kalkon', 'höns', 'fisk', 'ansjovis', 'sardell', 'makrill', 'kräft',
      'krabb', 'hummer', 'mussl', 'ostron', 'kaviar', 'bivax', 'propolis', 'karmin', 'kochenill',
      'cochenill', 'schellack', 'shellack', 'lanolin', 'kollagen', 'husbloss', 'yoghurt', 'kvarg',
      'helägg', 'kalvfond', 'oxfond', 'oxbuljong', 'viltfond', 'ankfett', 'gåsfett',
      'feta-ost', 'fetaost', 'getost', 'fårost', 'färskost', 'mjukost', 'hårdost', 'smältost',
      'prästost', 'herrgårdsost', 'grevéost', 'hushållsost', 'cheddarost', 'västerbottensost',
      'mozzarellaost', 'rivost', 'lagrad ost', 'riven ost', 'crème fraiche', 'creme fraiche',
      'crème fraîche', 'animalisk',
      // Seafood inside compounds (nordhavsräkor, kallvattenräkor, havskräfta) and Latin names
      'räka', 'räkor', 'räkan', 'skaldjur', 'scampi', 'krill', 'surimi', 'calamar', 'sardin',
      'anjovis', 'snigel', 'escargot', 'pandalus', 'penaeus', 'litopenaeus', 'salmo ', 'gadus',
      'clupea', 'thunnus', 'oncorhynchus', 'mytilus',
      // Fish species ("ansjovis" in Sweden is spiced sprat: the list says "skarpsill")
      'skarpsill', 'matjessill', 'kryddsill', 'inlagd sill', 'strömming', 'sprattus', 'engraulis',
      'siklöja', 'kolja', 'abborre', 'gädda', 'rödspätta', 'hälleflundra', 'piggvar', 'röding',
      'tilapia', 'pangasius', 'hoki', 'pollock', 'kummel', 'dorade', 'gravlax', 'stenbit', 'havskatt',
      'sjötunga', 'harengus', 'scomber', 'sardina', 'sardinops',
      // Fish roe ("arom" also ends in -rom, so these are listed one by one)
      'löjrom', 'sikrom', 'laxrom', 'forellrom', 'torskrom', 'stenbitsrom', 'fiskrom', 'regnbågsrom',
      'röding­srom', 'rödingsrom', 'tobiskungsrom', 'lodjursrom', 'capelinrom', 'loddarom', 'masago',
      'tobiko', 'coregonus', 'mallotus', 'cyclopterus', 'acipenser', 'romsås', 'rommen',
      'störrom', 'caviar', 'oscietra', 'osietra', 'sevruga', 'stjärnstör', 'huso huso', 'rödrom', 'svartrom', 'kaviaar',
      // Danish / Norwegian
      'mælk', 'melk', 'valle', 'myse', 'fløde', 'fløte', 'smør', 'honning', 'kylling', 'kød', 'kjøtt'
    ],
    start: [
      'ost', 'ägg', 'lax', 'torsk', 'sill', 'räk', 'skinka', 'bacon', 'ister', 'talg', 'späck',
      'blod', 'lever', 'lamm', 'kalv', 'anka', 'vilt', 'hjort', 'parmesan', 'parmigiano',
      'mozzarella', 'cheddar', 'ricotta', 'mascarpone', 'halloumi', 'pecorino', 'gouda',
      'emmentaler', 'gruyère', 'grana padano', 'smetana', 'ghee', 'keso', 'æg', 'öring', 'löja'
    ],
    word: [
      'milk', 'whey', 'butter', 'cream', 'cheese', 'egg', 'eggs', 'honey', 'gelatin', 'gelatine',
      'beef', 'pork', 'chicken', 'turkey', 'fish', 'anchovy', 'anchovies', 'shrimp', 'shrimps',
      'prawn', 'prawns', 'lard', 'tallow', 'casein', 'caseinate', 'lactose', 'beeswax', 'carmine',
      'cochineal', 'shellac', 'lanolin', 'collagen', 'bacon', 'ham', 'yogurt', 'yoghurt',
      'buttermilk', 'isinglass', 'fil', 'feta', 'brie', 'sej', 'gös', 'ål'
    ]
  };

  const ROM_LABEL = 'rom (rum or fish roe)';
  // Words that can be animal or plant derived, so we can't tell.
  const UNSURE_PATTERNS = [
    { re: /mono-?\s*(?:och|and|&)\s*di-?glycerid\p{L}*/giu, label: 'mono- och diglycerider' },
    { re: /(?<!\p{L})(?:vitamin\s*d3|d3-vitamin|kolekalciferol|cholecalciferol)(?!\p{L})/giu, label: 'vitamin D3' },
    { re: /(?<!\p{L})l-?cystein\p{L}*/giu, label: 'L-cystein' },
    { re: /(?<!\p{L})omega-?3(?![\p{L}\d])/giu, label: 'omega-3' },
    { re: /(?<!\p{L})rom(?!\p{L})/giu, label: ROM_LABEL },
    { re: /(?<!\p{L})(?:laktitol|lactitol)(?!\p{L})/giu, label: 'laktitol' },
    { re: /(?<!\p{L})(?:stearinsyra|stearic acid)(?!\p{L})/giu, label: 'stearinsyra' }
  ];

  const E_NOT = { '120': 'E120 (karmin)', '441': 'E441 (gelatin)', '542': 'E542 (benfosfat)',
    '901': 'E901 (bivax)', '904': 'E904 (schellack)', '913': 'E913 (lanolin)', '1105': 'E1105 (lysozym från ägg)' };
  const E_UNSURE = ['470', '471', '472', '473', '474', '475', '477', '481', '482', '570', '422',
    '627', '631', '635', '920', '966'];

  // Clauses about cross-contamination. Most vegans accept these, so they're noted, not flagged.
  const MAY_CONTAIN_RE = /(?:kan innehålla|kan förekomma|kan finnas|spår av|may contain|traces of|tillverka[dst]? i en (?:fabrik|anläggning)|framställ[dst]? i en (?:fabrik|anläggning)|hanteras i samma|produced in a factory|made in a factory)[^.;]*[.;]?/giu;

  // Context that makes the next animal word plant-based ("vegansk ost").
  const VEG_BEFORE_RE = /(?:vegansk\p{L}*|vegetabilisk\p{L}*|växtbaserad\p{L}*|vegan|plant[- ]based|dairy[- ]free|kakao|cacao|cocoa|shea|jordnöt\p{L}*|jordnød\p{L}*|peanut|mandel|nöt|cashew|kokos|coconut|havre|soja|sesam)[\s-]+$/iu;
  // Compound words that start with a plant word ("havremjölkchoklad", "vegokyckling").
  const VEG_PREFIX_RE = /^(?:vego|vegan|vegetabil|soja|havre|ärt|växt|plant|quorn|oumph|mandel|kokos|cashew|jordnöt|tång|sjögräs|alg|seaweed|kelp)/iu;
  const CULTURE_SUFFIX_RE = /(?:kultur|kulturer|kulturen|bakterier|bakterie|bakteriekultur|bakteriekulturer|culture|cultures)$/iu;
  // Flavourings named after an animal food ("smörarom") are usually synthetic.
  const FLAVOUR_SUFFIX_RE = /(?:arom|aromer|aroma|smak|flavour|flavor|flavouring|flavoring)$/iu;

  // "vegetabiliskt emulgeringsmedel (E471)", "vegetabiliska mono- och diglycerider",
  // "E471 (vegetabiliskt ursprung)", "vitamin D3 (från lav)": the shop says it's plant-derived.
  const PLANT_SOURCE_BEFORE_RE = /(?:vegetabilisk\p{L}*|växtbaserad\p{L}*|vegetable|plant-based|vegetabil\p{L}*)\s+(?:[\p{L}-]+\s+){0,3}\(?\s*$/iu;
  const PLANT_SOURCE_AFTER_RE = /^\s*\)?\s*\(?\s*(?:av\s+|från\s+|from\s+|of\s+)?(?:vegetabilisk\p{L}*|växt\p{L}*|vegetable|plant\p{L}*|lav|lichen|alg\p{L}*|svamp\p{L}*|jäst)/iu;
  function plantSourced(text, index, length) {
    const before = text.slice(Math.max(0, index - 60), index);
    const lastComma = Math.max(before.lastIndexOf(','), before.lastIndexOf(';'));
    const clause = lastComma >= 0 ? before.slice(lastComma + 1) : before;
    return PLANT_SOURCE_BEFORE_RE.test(clause) || PLANT_SOURCE_AFTER_RE.test(text.slice(index + length, index + length + 40));
  }

  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  const SAFE_RE = new RegExp('(?:' + SAFE_PHRASES.map(escapeRe).join('|') + ')', 'giu');
  const ANY_RE = new RegExp('(?<!\\p{L})\\p{L}*(?:' + NOT_VEGAN.any.map(escapeRe).join('|') + ')\\p{L}*', 'giu');
  const START_RE = new RegExp('(?<!\\p{L})(?:' + NOT_VEGAN.start.map(escapeRe).join('|') + ')\\p{L}*', 'giu');
  const WORD_RE = new RegExp('(?<!\\p{L})(?:' + NOT_VEGAN.word.map(escapeRe).join('|') + ')(?!\\p{L})', 'giu');
  const E_RE = /(?<![\p{L}\d])e\s?-?(\d{3,4})[a-f]?(?!\d)/giu;

  function normalise(text) {
    return String(text || '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .replace(/^\s*(?:ingredienser|ingredients)\s*:?\s*/u, '')
      .trim();
  }

  function pushUnique(list, item) {
    if (item && !list.includes(item)) list.push(item);
  }

  /**
   * Classify one ingredient list.
   * @returns {{status: string, reasons: string[], unsure: string[], mayContain: boolean}}
   */
  function classifyIngredients(raw) {
    let text = normalise(raw);
    const result = { status: 'unknown', reasons: [], unsure: [], mayContain: false };
    if (text.length < 2) return result;

    text = text.replace(MAY_CONTAIN_RE, (m) => { result.mayContain = true; return ' '; });
    text = text.replace(SAFE_RE, ' ');

    const consider = (match, index) => {
      const token = match.trim();
      if (!token) return;
      if (VEG_PREFIX_RE.test(token)) return;
      // Cultures and bacteria are microbes, not animal products ("yoghurtkultur", "filbakterier").
      if (CULTURE_SUFFIX_RE.test(token)) return;
      // "Free from" words name what's NOT in it: laktosfri, laktosefri, mælkefri, äggfritt
      if (/(?:fri|fritt|fria|frie)$/iu.test(token)) return;
      if (/^\s*(?:cultures?|kulturer|kultur|bakterier)(?!\p{L})/iu.test(text.slice(index + match.length, index + match.length + 20))) return;
      if (VEG_BEFORE_RE.test(text.slice(Math.max(0, index - 30), index))) return;
      if (FLAVOUR_SUFFIX_RE.test(token)) { pushUnique(result.unsure, token); return; }
      pushUnique(result.reasons, token);
    };

    for (const re of [ANY_RE, START_RE, WORD_RE]) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(text))) consider(m[0], m.index);
    }

    E_RE.lastIndex = 0;
    let e;
    while ((e = E_RE.exec(text))) {
      const code = e[1];
      if (E_NOT[code]) pushUnique(result.reasons, E_NOT[code]);
      else if (E_UNSURE.includes(code) && !plantSourced(text, e.index, e[0].length)) pushUnique(result.unsure, 'E' + code);
    }

    for (const { re, label } of UNSURE_PATTERNS) {
      re.lastIndex = 0;
      let u;
      while ((u = re.exec(text))) {
        // Omega-3 from algae is fine
        if (label === 'omega-3' && /alg|algae/iu.test(text)) break;
        if (plantSourced(text, u.index, u[0].length)) continue;
        pushUnique(result.unsure, label);
        break;
      }
    }

    if (result.reasons.length) result.status = 'not';
    else if (result.unsure.length) result.status = 'unsure';
    else result.status = 'vegan';
    return result;
  }

  /** Map Open Food Facts' ingredients_analysis_tags to a verdict. */
  function fromOpenFoodFacts(tags) {
    const t = Array.isArray(tags) ? tags : [];
    if (t.includes('en:non-vegan')) return { status: 'not', reasons: ['per Open Food Facts'], unsure: [], mayContain: false };
    if (t.includes('en:vegan')) return { status: 'vegan', reasons: [], unsure: [], mayContain: false };
    if (t.includes('en:maybe-vegan')) return { status: 'unsure', reasons: [], unsure: ['per Open Food Facts'], mayContain: false };
    return null;
  }

  // Fresh produce has no ingredient list; the name or ICA's category says what it is.
  const PLANT_WORDS = [
    'tomat', 'potatis', 'sötpotatis', 'champinjon', 'svamp', 'kantarell', 'skivling', 'ostronskivling', 'shiitake', 'portabello', 'karljohan',
    'lök', 'rödlök', 'vitlök', 'purjolök', 'schalottenlök', 'gurka', 'paprika', 'chili', 'sallad',
    'isberg', 'rucola', 'spenat', 'grönkål', 'kål', 'vitkål', 'rödkål', 'brysselkål', 'blomkål',
    'broccoli', 'morot', 'morötter', 'rödbeta', 'betor', 'palsternacka', 'rotselleri', 'selleri',
    'fänkål', 'sparris', 'rädisa', 'kålrot', 'zucchini', 'squash', 'pumpa', 'aubergine', 'majs',
    'ingefära', 'gurkmeja', 'avokado', 'banan', 'äpple', 'äpplen', 'päron', 'apelsin', 'clementin',
    'mandarin', 'citron', 'lime', 'grapefrukt', 'mango', 'ananas', 'kiwi', 'melon', 'vattenmelon',
    'persika', 'nektarin', 'plommon', 'aprikos', 'druva', 'vindruvor', 'bär', 'blåbär', 'jordgubb',
    'hallon', 'björnbär', 'lingon', 'tranbär', 'granatäpple', 'fikon', 'dadel', 'kokosnöt',
    'basilika', 'persilja', 'dill', 'koriander', 'mynta', 'rosmarin', 'timjan', 'gräslök',
    'sugarsnaps', 'haricots', 'bönor', 'ärtor'
  ];
  // The whole word must be the produce, optionally with a variety in front ("babyplommontomater"),
  // so "smörgåsgurka" (pickles) or "potatisgratäng" don't count.
  const PLANT_TOKEN_RE = new RegExp('^(?:baby|plommon|körsbärs|cocktail|kvist|mini|röd|gul|grön|vit|svart|söt|blod|eko|vild|färsk)*(?:' + PLANT_WORDS.map(escapeRe).join('|') + ')(?:er|ar|or|n|na|en)?$', 'u');
  const DISH_RE = /(?:gratäng|soppa|sås|paj|pizza|mos|röra|bullar|biff|wok|gryta|lasagne|pasta|chips|sylt|juice|dryck|kaka)/u;
  const PRODUCE_CLASS_RE = /(?<!\p{L})klass\s*(?:1|2|i|ii)(?!\p{L})/iu;
  // Top-level ICA categories that aren't food. Without an ingredient list, there's nothing to say.
  const NON_FOOD_RE = /^(?:städ|tvätt|kök|hem|hushåll|fritid|blommor|kläder|tobak|apotek|djur|skönhet|träning|hygien|hälsa|kiosk|tidningar)/iu;

  function looksLikeProduce(name, category) {
    const top = (category && category[0]) || '';
    if (isNonFood(category)) return false; // "Diskmedel Citron" is soap, not a lemon
    if (/^frukt\s*(?:&|och)?\s*grön/iu.test(top)) return true;
    const n = String(name || '').toLowerCase();
    if (PRODUCE_CLASS_RE.test(n)) return true;
    const tokens = n.split(/[^\p{L}]+/u).filter(Boolean);
    if (tokens.some((t) => DISH_RE.test(t))) return false;
    return tokens.slice(0, 3).some((t) => PLANT_TOKEN_RE.test(t));
  }

  // Names that settle it: a product called "Räkor" or "Kycklingfilé" isn't vegan,
  // whatever its ingredient list seems to say.
  // Long words can sit inside compounds (nordhavsräkor); short ones must start a word ("pålägg", "Galaxy").
  const NAME_ANIMAL_RE = /(?<!\p{L})(?:\p{L}*(?:löjrom|sikrom|laxrom|forellrom|torskrom|stenbitsrom|fiskrom|störrom|caviar|oscietra|rostbiff|högrev|fransyska|kassler|karré|revben|kotlett|lammstek|kalvstek|nötstek|viltfärs|hjortfärs|älgfärs|innanlår|ytterlår|biff|ansjovis|strömming|skarpsill|gravlax|sardin|fisk|räka|räkor|kyckling|tonfisk|makrill|fläsk|bacon|skinka|nötfärs|nötkött|blandfärs|köttfärs|kalkon|entrecôte|oxfilé|ryggbiff|salami|chorizo|prosciutto|leverpastej|musslor|hummer|kräftor|krabba|bläckfisk|ostron|kaviar|honung|helägg|hönsägg)|(?:lax|torsk|sill|lamm|biff|korv|ägg))\p{L}*/giu;

  // Seaweed "caviar" (tångkaviar) is plant-based too
  const PLANT_PROTEIN_RE = /(?:tång|sjögräs|seaweed|kelp|alg(?:er|kaviar)|agar)\p{L}*|(?:ärt|soja|soy|pea|vete|wheat|bön|fava|havre|oat|potatis|rapsfrö|solros|hampa|mung)\p{L}*\s*-?protein|protein\p{L}*\s*\((?:ärt|soja|vete|bön|fava)|vetegluten|wheat gluten|seitan|tofu|tempeh|jackfrukt|jackfruit|mykoprotein|mycoprotein|texturerat|texturised|texturized/iu;

  function animalInName(name) {
    const n = String(name || '').toLowerCase().replace(SAFE_RE, ' ');
    NAME_ANIMAL_RE.lastIndex = 0;
    let m;
    while ((m = NAME_ANIMAL_RE.exec(n))) {
      const token = m[0];
      if (VEG_PREFIX_RE.test(token)) continue;                       // vegokorv, havrehonung
      if (/(?:fri|fritt|fria)$/u.test(token)) continue;               // äggfri
      if (/^ägg(?:plant|nudl)/u.test(token)) continue;
      if (VEG_BEFORE_RE.test(n.slice(Math.max(0, m.index - 30), m.index))) continue; // vegansk korv
      if (/(?<!\p{L})(?:vegansk|vegan|vego|växtbaserad|plant-based|vegetarisk)/iu.test(n)) continue;
      return token;
    }
    return null;
  }

  // Shelved under fish/seafood or meat (and not in a vegetarian subcategory)
  const ANIMAL_CATEGORY_RE = /^(?:fisk|skaldjur|kött|chark|fågel)/iu;
  function animalCategory(category) {
    if (!category || !category.length) return null;
    if (category.some((c) => /veg|växt|plant/iu.test(c))) return null;
    return ANIMAL_CATEGORY_RE.test(String(category[0]).trim()) ? category[0] : null;
  }

  const STRONG_ANIMAL_RE = /kött|fläsk|fisk|kyckling|räk|lax|torsk|sill|bacon|skinka|gelatin|kalkon|lamm|biff|korv|rom$|kaviar|caviar|sold as/iu;

  const NON_FOOD_NOT = [
    [/(?<!\p{L})tändstick\p{L}*/iu, 'tändstickor (gelatin in the match head)'],
    [/(?<!\p{L})bivax\p{L}*/iu, 'bivax (beeswax)'],
    [/(?<!\p{L})(?:merino|lamm)?(?:ull|ylle)(?:\p{L}*)(?<!fri)(?!\p{L})/iu, 'ull (wool)'],
    [/(?<!\p{L})(?:läder|skinn|mockaskinn)(?:\p{L}*)(?<!fri)(?!\p{L})/iu, 'läder (leather)'],
    [/(?<!\p{L})(?:siden|silke)\p{L}*/iu, 'siden (silk)'],
    [/(?<!\p{L})dun(?:jacka|kudde|täcke|väst|filt|sovsäck)\p{L}*/iu, 'dun (down feathers)'],
    [/(?<!\p{L})(?:lanolin|shellack|schellack)\p{L}*/iu, 'animal-derived']
  ];
  const NON_FOOD_UNSURE = [[/(?<!\p{L})stearin\p{L}*/iu, 'stearin (plant or animal fat)']];
  function nonFoodAnimal(name, nonFoodShelf) {
    const n = String(name || '');
    if (/(?<!\p{L})(?:vegansk\p{L}*|vegan|veg|konst|faux|syntet\p{L}*|vegetabilisk\p{L}*|soja|raps|växt\p{L}*)(?!\p{L})|konstläder|fuskpäls/iu.test(n)) return null;
    for (const [re, why] of NON_FOOD_NOT) {
      // Textile/leather words also appear in food ("Mocka" coffee), so they need a non-food shelf
      const textile = /ull|läder|siden|dun/.test(why);
      if (re.test(n) && (!textile || nonFoodShelf)) return { status: 'not', reasons: [why], unsure: [], mayContain: false };
    }
    for (const [re, why] of NON_FOOD_UNSURE) if (re.test(n)) return { status: 'unsure', reasons: [], unsure: [why], mayContain: false };
    return null;
  }

  function isNonFood(category) {
    return !!(category && category[0] && NON_FOOD_RE.test(category[0].trim()));
  }

  /**
   * Combine everything we know about one product.
   * info: { ingredients, name, claimVegan, offTags, offIngredients }
   * Returns the verdict plus `source` so the badge can say where it came from.
   */
  // "Adventskalender Godis Vegan", "Vegansk Bolognese", "100% Plant-based"
  const NAME_CLAIM_RE = /(?<!(?:ej|inte|icke|non|not)[\s-]?)(?<!\p{L})(?:vegan|vegansk|veganskt|veganska|växtbaserad|växtbaserat|plant-based|plantbaserad|100\s?% plant)(?!\p{L})/iu;

  // Brands that only make plant-based products: their "unsure" additives (E471, E472, D3…) are plant-derived.
  // Brands that sell both (Quorn, Garden Gourmet, Hälsans Kök) are deliberately not here.
  const VEGAN_BRANDS = [
    'oatly', 'oddlygood', 'alpro', 'planti', "naturli'", 'naturli', 'oumph', 'anamma', 'beyond meat',
    'violife', 'planted', 'sproud', 'mighty', 'astrid och aporna', 'farmers & chefs', 'sojade',
    'provamel', 'tofutown', 'nomoo', 'rebel kitchen', 'vegme', 'fry\'s', 'jävligt gott', 'oatside',
    'mycorena', 'like meat', 'heura', 'no meat', 'vly', 'koko', 'flora plant', 'naturli´', 'cavi-art', 'cavi art'
  ];
  const VEGAN_BRAND_RE = new RegExp('(?<!\\p{L})(?:' + VEGAN_BRANDS.map(escapeRe).join('|') + ')(?!\\p{L})', 'iu');

  // "Laktosefri for veganer", "egnet for veganere", "lämplig för veganer", "suitable for vegans"
  // Also allows a couple of words in between: "Lämplig även för vegan och vegetarisk matlagning"
  const TEXT_CLAIM_RE = /(?:(?:lämplig\p{L}*|passar|egnet|velegnet|anbefales|suitable|ideal)\s+(?:\p{L}+\s+){0,2}(?:för|for|til)\s+(?:\p{L}+\s+){0,2}vegan\p{L}*|(?<!\p{L})(?:för|for)\s+vegan(?:er|ere|s)?(?!\p{L}))/iu;

  function classifyProduct(info) {
    info = Object.assign({}, info || {});
    const text = String(info.ingredients || '') + ' ' + String(info.description || '');
    if (TEXT_CLAIM_RE.test(text) && !/(?:ej|inte|icke|ikke|not)\s+(?:lämplig|egnet|suitable)/iu.test(text)) info.claimVegan = true;
    if (NAME_CLAIM_RE.test(String(info.name || ''))) info.claimVegan = true;
    if (VEGAN_BRAND_RE.test(String(info.brand || '')) || VEGAN_BRAND_RE.test(String(info.name || ''))) info.claimVegan = true;
    let v = null;
    let source = null;

    if (info.ingredients && normalise(info.ingredients).length > 2) {
      v = classifyIngredients(info.ingredients);
      source = 'ingredients';
    } else if (info.offIngredients && normalise(info.offIngredients).length > 2) {
      v = classifyIngredients(info.offIngredients);
      source = 'openfoodfacts';
    } else if (info.offTags && fromOpenFoodFacts(info.offTags)) {
      v = fromOpenFoodFacts(info.offTags);
      source = 'openfoodfacts';
    } else if (info.name) {
      // No ingredient list (often single-ingredient goods like "Kycklingfilé" or "Lax").
      // Only trust the name to say "not vegan"; a plain name can't prove it's vegan.
      // Only clear-cut names decide on their own ("Kycklingfilé", "Räkor"); "Smörgåsgurka" doesn't.
      const word = animalInName(info.name);
      if (word) { v = { status: 'not', reasons: [word], unsure: [], mayContain: false }; source = 'name'; }
      else if (looksLikeProduce(info.name, info.category)) {
        v = { status: 'vegan', reasons: [], unsure: [], mayContain: false };
        source = 'produce';
      }
    }
    // Safety net for names like "Räkor" or "Chorizo". Plant-based versions use the same names,
    // so an ingredient list with plant protein wins; otherwise it's never called vegan.
    if (v && v.status === 'vegan' && !info.claimVegan) {
      const word = animalInName(info.name);
      if (word) {
        const text = String(info.ingredients || info.offIngredients || '');
        if (!text) {
          v = { status: 'not', reasons: [word], unsure: [], mayContain: false };
          source = 'name';
        } else if (!PLANT_PROTEIN_RE.test(text)) {
          v = { status: 'unsure', reasons: [], unsure: [`name says ${word}`], mayContain: v.mayContain, conflict: false };
        }
      }
    }
    // A plain "rom" is rum in sweets, cakes and drinks (Punschpokal), roe in fish products.
    if (v && v.unsure.includes(ROM_LABEL)) {
      const text = String(info.ingredients || info.offIngredients || '') + ' ' + String(info.name || '');
      const fishy = animalCategory(info.category) || /fisk|lax|sill|kaviar|caviar|skaldjur|torsk|stenbit|löja|sik(?!t)/iu.test(text)
        || (info.category || []).some((c) => /fisk|skaldjur|kaviar|rom/iu.test(c));
      const sweet = (info.category && info.category.length && !fishy)
        || /punsch|choklad|kakao|socker|sirap|godis|pralin|likör|alkohol|russin|marsipan|tryffel|kaka|kakor|glass/iu.test(text);
      if (sweet && !fishy) {
        const unsure = v.unsure.filter((u) => u !== ROM_LABEL);
        v = Object.assign({}, v, { unsure, status: v.status === 'unsure' && !unsure.length ? 'vegan' : v.status });
      }
    }

  // Category safety net: something the shop files under fish/seafood or meat isn't called vegan
    // (or left unknown) unless it's labelled vegan or its list names a plant protein.
    const shelf = animalCategory(info.category);
    if (shelf && !info.claimVegan && (!v || ['vegan', 'unsure', 'unknown'].includes(v.status))) {
      const text = String(info.ingredients || info.offIngredients || '');
      const plantName = /(?<!\p{L})(?:tång|sjögräs|seaweed|kelp|alg)\p{L}*/iu.test(String(info.name || ''));
      if (!plantName && (!text || !PLANT_PROTEIN_RE.test(text))) {
        v = { status: 'not', reasons: [`sold as ${String(shelf).toLowerCase()}`].concat((v && v.reasons) || []), unsure: [], mayContain: !!(v && v.mayContain) };
        source = source || 'category';
      }
    }
    // Non-food that's typically made from animals (no ingredient list to check)
    if (!v || v.status === 'unknown') {
      const nf = nonFoodAnimal(info.name, isNonFood(info.category));
      if (nf) { v = nf; source = 'nonfood-known'; }
    }
    if (!v && isNonFood(info.category)) {
      // Not food and no ingredient list: show nothing rather than a pointless badge.
      v = { status: 'skip', reasons: [], unsure: [], mayContain: false };
      source = 'nonfood';
    }

    if (!v) v = { status: 'unknown', reasons: [], unsure: [], mayContain: false };

    if (info.claimVegan) {
      if (v.status === 'unknown' || v.status === 'unsure') {
        v = Object.assign({}, v, { status: 'vegan' });
        source = source || 'label';
      } else if (v.status === 'not') {
        // Clear meat, fish or gelatin beats any "vegan" label (which may have been misread).
        const clear = v.reasons.some((r) => STRONG_ANIMAL_RE.test(r)) || animalCategory(info.category);
        if (!clear) {
          // Otherwise the label and our word list disagree; don't pretend to know.
          v = Object.assign({}, v, { status: 'unsure', unsure: v.reasons.concat(v.unsure), reasons: [], conflict: true });
        }
      }
    }
    return Object.assign({ source }, v);
  }

  const api = { VERDICT_VERSION, classifyIngredients, classifyProduct, fromOpenFoodFacts, looksLikeProduce };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.VH = Object.assign(root.VH || {}, api);
})(typeof globalThis !== 'undefined' ? globalThis : this);
