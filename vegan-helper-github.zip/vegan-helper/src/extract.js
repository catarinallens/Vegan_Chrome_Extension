/*
 * Vegan Helper: pulls product facts (ingredients, barcode, name, "vegan" label)
 * out of whatever the shop gives us: a JSON API response, a product page's HTML,
 * or the live page the user is looking at.
 */
(function (root) {
  'use strict';

  const INGREDIENT_KEY_RE = /ingredien|ingredient/i;
  const TITLE_KEYS = ['title', 'name', 'label', 'heading', 'key', 'type', 'header', 'id'];
  const BODY_KEYS = ['content', 'value', 'text', 'body', 'description', 'data', 'values', 'html'];
  const EAN_KEY_RE = /^(?:ean|eans|ean13|eancode|gtin|gtins|gtin13|gtin14|gtin8|barcode|barcodes)$/i;
  const CLAIM_RE = /^(?:vegan|vegansk|veganskt|vegansk produkt|veganprodukt|lämplig för veganer|passar veganer|suitable for vegans|vegan product|100 ?% vegan)$/i;
  const OTHER_PLACES_RE = /filter|facet|categor|navigation|breadcrumb|menu|related|recommend|suggest|similar|alternativ|crossSell|upSell|adverts?|banner/i;
  const NEXT_SECTION_RE = /(?:näringsvärde|näringsinnehåll|näringsdeklaration|allergener|förvaring|ursprung|ursprungsland|tillverkare|bruksanvisning|användning|produktinformation|återvinning|kontaktinformation|övrig information|nutrition|storage|allergy)/i;

  const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', auml: 'ä', ouml: 'ö', aring: 'å', Auml: 'Ä', Ouml: 'Ö', Aring: 'Å', eacute: 'é', egrave: 'è' };

  function decodeEntities(s) {
    return s
      .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
      .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
      .replace(/&([a-z]+);/gi, (m, n) => (n in ENTITIES ? ENTITIES[n] : m));
  }

  function stripHtml(s) {
    if (typeof s !== 'string') return '';
    return decodeEntities(
      s.replace(/<(?:br|\/p|\/li|\/div)\s*\/?>/gi, ' ')
        .replace(/<[^>]+>/g, '')
    ).replace(/\s+/g, ' ').trim();
  }

  function bodyText(v) {
    if (typeof v === 'string') return stripHtml(v);
    if (Array.isArray(v)) return v.map(bodyText).filter(Boolean).join(', ');
    if (v && typeof v === 'object') {
      for (const k of BODY_KEYS) if (k in v) { const t = bodyText(v[k]); if (t) return t; }
    }
    return '';
  }

  function eanFrom(v) {
    const list = Array.isArray(v) ? v : [v];
    for (const x of list) {
      const s = String(x == null ? '' : (typeof x === 'object' ? (x.value || x.code || x.ean || '') : x)).replace(/\D/g, '');
      if (s.length >= 8 && s.length <= 14) return s;
    }
    return null;
  }

  /** Walk any JSON value and collect product facts. */
  function factsFromJson(rootValue) {
    const facts = { ingredients: '', ean: null, name: '', claimVegan: false };
    const seen = new Set();
    const candidates = [];

    (function walk(v, key, depth, elsewhere) {
      if (depth > 14 || v == null) return;
      // Filters, menus and "related products" mention other products; don't read claims from them.
      if (key && OTHER_PLACES_RE.test(key)) elsewhere = true;
      if (typeof v === 'string') {
        const t = v.trim();
        if (!elsewhere && t.length < 40 && CLAIM_RE.test(t)) facts.claimVegan = true;
        if (elsewhere) return;
        if (key && INGREDIENT_KEY_RE.test(key)) candidates.push(stripHtml(t));
        return;
      }
      if (typeof v !== 'object' || seen.has(v)) return;
      seen.add(v);

      if (Array.isArray(v)) { v.forEach((x) => walk(x, key, depth + 1, elsewhere)); return; }
      if (elsewhere) { for (const [k, val] of Object.entries(v)) walk(val, k, depth + 1, true); return; }

      // { title: "Ingredienser", content: "<p>...</p>" }
      for (const tk of TITLE_KEYS) {
        if (typeof v[tk] === 'string' && INGREDIENT_KEY_RE.test(v[tk]) && v[tk].length < 40) {
          for (const bk of BODY_KEYS) {
            if (bk !== tk && bk in v) { const t = bodyText(v[bk]); if (t) candidates.push(t); }
          }
        }
      }

      for (const [k, val] of Object.entries(v)) {
        if (EAN_KEY_RE.test(k) && !facts.ean) facts.ean = eanFrom(val);
        if (!facts.name && /^(?:name|productName)$/.test(k) && typeof val === 'string' && depth <= 4) facts.name = val;
        if (!facts.brand && /^(?:brand|manufacturer|manufacturerName)$/.test(k) && typeof val === 'string' && depth <= 3) facts.brand = val;
        // Product description (ICA: bopData.detailedDescription) — may say "lämplig för veganer"
        if (!facts.description && /^(?:detailedDescription|longDescription|description)$/.test(k) && typeof val === 'string' && depth <= 3) facts.description = stripHtml(val).slice(0, 2000);
        if (!facts.brand && k === 'brand' && val && typeof val.name === 'string' && depth <= 3) facts.brand = val.name;
        // Axfood: breadCrumbs = [{ name: "Alla varor" }, { name: "Glass, godis & snacks" }, …]
        if (!facts.category && /^bread[cC]rumbs$/.test(k) && Array.isArray(val)) {
          const names = val.map((x) => (x && typeof x.name === 'string' ? x.name : null)).filter(Boolean)
            .filter((n) => !/^(?:hem|home|start|startsida|alla varor|all products)$/i.test(n));
          if (names.length) facts.category = names;
        }
        // ICA: product.categoryPath = ["Frukt & Grönt", "Grönsaker", ...]
        if (!facts.category && k === 'categoryPath' && Array.isArray(val)) facts.category = val.filter((x) => typeof x === 'string');
        if (INGREDIENT_KEY_RE.test(k) && val && typeof val === 'object') {
          const t = bodyText(val);
          if (t) candidates.push(t);
        }
        walk(val, k, depth + 1, false);
      }
    })(rootValue, '', 0, false);

    const good = candidates
      .map((c) => c.replace(/^\s*(?:ingredienser|ingredients)\s*:?\s*/i, '').trim())
      .filter((c) => c.length > 2);
    if (good.length) facts.ingredients = good.sort((a, b) => b.length - a.length)[0];
    return facts;
  }

  /** Find `marker = {...}` in a script and parse the object. */
  function parseAssignedJson(html, marker) {
    const at = html.indexOf(marker);
    if (at < 0) return null;
    const start = html.indexOf('{', at);
    if (start < 0) return null;
    let depth = 0, inStr = false, esc = false;
    for (let i = start; i < html.length; i++) {
      const c = html[i];
      if (inStr) {
        if (esc) esc = false;
        else if (c === '\\') esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') inStr = true;
      else if (c === '{') depth++;
      else if (c === '}') {
        depth--;
        if (depth === 0) {
          try { return JSON.parse(html.slice(start, i + 1)); } catch (e) { return null; }
        }
      }
    }
    return null;
  }

  function merge(into, from) {
    if (!from) return into;
    if (!into.ingredients && from.ingredients) into.ingredients = from.ingredients;
    if (!into.ean && from.ean) into.ean = from.ean;
    if (!into.name && from.name) into.name = from.name;
    if (!into.category && from.category) into.category = from.category;
    if (!into.brand && from.brand) into.brand = from.brand;
    if (!into.description && from.description) into.description = from.description;
    if (from.claimVegan) into.claimVegan = true;
    return into;
  }

  /** Text after an "Ingredienser" heading, up to the next section. */
  function ingredientsFromText(text) {
    const m = /(?:^|[\s>])(?:ingredienser|ingredients)\s*:?\s*/i.exec(text);
    if (!m) return '';
    let rest = text.slice(m.index + m[0].length, m.index + m[0].length + 2500);
    const next = NEXT_SECTION_RE.exec(rest);
    if (next && next.index > 3) rest = rest.slice(0, next.index);
    rest = rest.trim();
    return rest.length > 2 ? rest : '';
  }

  /**
   * Products the shop itself marks as vegan, from the product data embedded in a page.
   * Mathem: {"id":1663, …, "clientClassifiers":[{"name":"Veganskt", "imageUrl":"…/classifier_icons/vegan…"}]}
   */
  function veganMarkedIds(html) {
    const vegan = new Set();
    if (typeof html !== 'string' || html.indexOf('clientClassifiers') < 0) return vegan;
    const text = html.replace(/\\\\"/g, '"').replace(/\\"/g, '"');
    const re = /"clientClassifiers":\[(.*?)\]/g;
    let m;
    while ((m = re.exec(text))) {
      if (!/classifier_icons\/vegan|"name":"Vegansk?t?"/.test(m[1])) continue;
      const back = text.slice(Math.max(0, m.index - 2500), m.index);
      const ids = back.match(/"id":(\d+),/g);
      if (ids) vegan.add(ids[ids.length - 1].replace(/\D/g, ''));
    }
    return vegan;
  }

  /** Facts from a product page's raw HTML (fetched in the background). */
  function factsFromHtml(html, key) {
    const facts = { ingredients: '', ean: null, name: '', claimVegan: false };
    if (typeof html !== 'string') return facts;
    if (key != null && veganMarkedIds(html).has(String(key))) facts.claimVegan = true;

    merge(facts, factsFromJson(parseAssignedJson(html, '__INITIAL_STATE__')));
    merge(facts, factsFromJson(parseAssignedJson(html, '__PRELOADED_STATE__')));

    const next = /<script[^>]*id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i.exec(html);
    if (next) { try { merge(facts, factsFromJson(JSON.parse(next[1]))); } catch (e) { /* ignore */ } }

    const ldRe = /<script[^>]*application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi;
    let ld;
    while ((ld = ldRe.exec(html))) { try { merge(facts, factsFromJson(JSON.parse(ld[1]))); } catch (e) { /* ignore */ } }

    // <h2>Ingredienser</h2><p>…</p> (handla.ica.se)
    if (!facts.ingredients) {
      const sec = /<h[1-6][^>]*>\s*(?:ingredienser|ingredients)\s*:?\s*<\/h[1-6]>\s*([\s\S]*?)(?=<h[1-6][\s>]|<\/section>|<\/div>)/i.exec(html);
      if (sec) facts.ingredients = stripHtml(sec[1]);
    }
    // <span>Ingredienser</span></div><div>…</div> (Mathem: a label column, then a value column)
    if (!facts.ingredients) {
      const sec = />\s*(?:ingredienser|ingredients)\s*:?\s*<\/(?:span|dt|th|strong|b|p)>\s*(?:<\/div>\s*)?<(?:div|dd|td)[^>]*>([\s\S]*?)<\/(?:div|dd|td)>/i.exec(html);
      if (sec) facts.ingredients = stripHtml(sec[1].replace(/<!--[\s\S]*?-->/g, ''));
    }
    // Category from the page's breadcrumb data (Mathem): Hem › Alla varor › Frukt & grönt › …
    if (!facts.category) {
      const crumbs = /"@type"\s*:\s*"BreadcrumbList"[\s\S]*?"itemListElement"\s*:\s*(\[[\s\S]*?\])\s*\}/.exec(html);
      if (crumbs) {
        try {
          const names = JSON.parse(crumbs[1]).map((x) => stripHtml(String(x.name || ''))).filter(Boolean)
            .filter((n) => !/^(?:hem|home|start|startsida|alla varor|all products)$/i.test(n));
          if (names.length) facts.category = names;
        } catch (e) { /* ignore */ }
      }
    }
    if (!facts.name) {
      const h1 = /<h1[^>]*>([\s\S]*?)<\/h1>/i.exec(html);
      if (h1) facts.name = stripHtml(h1[1]);
    }

    if (!facts.ingredients) {
      const body = html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ');
      facts.ingredients = ingredientsFromText(stripHtml(body));
    }
    return facts;
  }

  /** Facts from the live, rendered page (works even when the HTML is an empty app shell). */
  function factsFromDom(doc) {
    const facts = { ingredients: '', ean: null, name: '', claimVegan: false };
    const els = doc.querySelectorAll('h1,h2,h3,h4,h5,h6,dt,th,button,summary,strong,b,span,div,p,label');
    let best = '';
    for (const el of els) {
      if (el.closest('[data-vh-ui]')) continue;
      const own = (el.textContent || '').trim();
      if (own.length > 3000) continue;
      if (/^(?:ingredienser|ingredients)\s*:?$/i.test(own)) {
        // Heading on its own: content is a following sibling, or the rest of the parent.
        let t = '';
        // Only the element right after the heading: never wander into the next field ("Sverige")
        const sib = el.nextElementSibling;
        if (sib) t = (sib.textContent || '').trim();
        if (!t && el.parentElement) t = ingredientsFromText((el.parentElement.textContent || '').trim());
        if (!t && el.parentElement && el.parentElement.nextElementSibling) t = (el.parentElement.nextElementSibling.textContent || '').trim();
        if (t.length > best.length && t.length < 3000) best = t;
      } else if (/^(?:ingredienser|ingredients)\s*:\s*\S/i.test(own) && own.length < 3000 && el.children.length < 6) {
        const t = ingredientsFromText(own);
        if (t.length > best.length) best = t;
      }
    }
    const next = NEXT_SECTION_RE.exec(best);
    if (next && next.index > 3) best = best.slice(0, next.index);
    facts.ingredients = best.trim();

    // Structured product data the page added for itself (Coop puts "Ingredienser" here)
    for (const s of doc.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const data = JSON.parse(s.textContent);
        merge(facts, factsFromJson(data));
        // Breadcrumbs give the shop's category (Mathem: Fisk & skaldjur › Kaviar & rom)
        if (!facts.category && data && data['@type'] === 'BreadcrumbList' && Array.isArray(data.itemListElement)) {
          const names = data.itemListElement.map((x) => stripHtml(String((x && x.name) || ''))).filter(Boolean)
            .filter((n) => !/^(?:hem|home|start|startsida|alla varor|all products)$/i.test(n));
          if (names.length) facts.category = names;
        }
      } catch (e) { /* ignore */ }
    }

    const h1 = doc.querySelector('h1');
    if (h1) facts.name = h1.textContent.trim();
    // (No loose search for the word "Vegan" on screen: diet filters and menus say it too.)
    return facts;
  }

  /**
   * A stable product key from a product link.
   * Handles /products/{slug}/{id} and /products/{id}/details.
   */
  function productKeyFromHref(href, base) {
    let url;
    try { url = new URL(href, base); } catch (e) { return null; }
    const parts = url.pathname.split('/').filter(Boolean);
    const last = parts[parts.length - 1] || '';
    // Axfood (Willys, Hemköp): …-101773952_ST
    const code = /(\d+_[A-Z]{1,4})$/.exec(last);
    if (code && (parts.includes('produkt') || parts.includes('p'))) return code[1];
    // Coop: …/mjolkchoklad-7622202238475 (the barcode)
    const ean = /-(\d{8,14})$/.exec(last);
    if (ean && parts.includes('varor')) return ean[1];
    let i = parts.indexOf('products');
    if (i < 0) i = parts.indexOf('produkt');
    if (i < 0) return null;
    const rest = parts.slice(i + 1).filter((p) => !/^(?:details|detaljer|info)$/i.test(p));
    if (!rest.length) return null;
    const numeric = rest.filter((p) => /^\d+[A-Za-z]{0,3}$/.test(p));
    if (numeric.length) return numeric[numeric.length - 1];
    const leading = /^(\d+)-/.exec(rest[0]); // Mathem: 66111-marabou-mjolkchoklad
    return leading ? leading[1] : rest[rest.length - 1];
  }

  const api = { veganMarkedIds, factsFromJson, factsFromHtml, factsFromDom, productKeyFromHref, stripHtml, ingredientsFromText, parseAssignedJson };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.VH = Object.assign(root.VH || {}, api);
})(typeof globalThis !== 'undefined' ? globalThis : this);
