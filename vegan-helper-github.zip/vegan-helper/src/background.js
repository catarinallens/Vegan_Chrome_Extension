/*
 * Vegan Helper: background worker.
 * Looks products up on Open Food Facts by barcode when the shop doesn't
 * show an ingredient list.
 */
'use strict';

const OFF_URL = 'https://world.openfoodfacts.org/api/v2/product/';
const OFF_FIELDS = 'product_name,ingredients_text,ingredients_text_sv,ingredients_text_en,ingredients_analysis_tags,labels_tags';

async function lookupOpenFoodFacts(ean) {
  const res = await fetch(`${OFF_URL}${encodeURIComponent(ean)}.json?fields=${OFF_FIELDS}`);
  if (!res.ok) return { ok: false, status: res.status };
  const data = await res.json();
  if (!data || data.status !== 1 || !data.product) return { ok: false, status: 404 };
  const p = data.product;
  return {
    ok: true,
    name: p.product_name || '',
    ingredients: p.ingredients_text_sv || p.ingredients_text || p.ingredients_text_en || '',
    tags: p.ingredients_analysis_tags || [],
    claimVegan: (p.labels_tags || []).includes('en:vegan')
  };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'vh:off' && /^\d{8,14}$/.test(msg.ean || '')) {
    lookupOpenFoodFacts(msg.ean)
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true; // keep the channel open for the async answer
  }
  return false;
});
