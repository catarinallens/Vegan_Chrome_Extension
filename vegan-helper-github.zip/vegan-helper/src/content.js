/*
 * Vegan Helper: runs on the shop's pages.
 *  - finds every product on the page (search results, categories, cart)
 *  - checks each one's ingredients in the background
 *  - badges, hides or dims products, and shows the filter bar
 */
(function () {
  'use strict';

  const VH = globalThis.VH;
  if (!VH || window.__vegan_helper_loaded) return;
  const site = VH.siteFor(location.host);
  if (!site) return;
  window.__vegan_helper_loaded = true;

  const log = (...a) => console.debug('[Vegan helper]', ...a);

  const CACHE_KEY = 'vh-products-v1';
  const KEEP_MS = 14 * 24 * 3600 * 1000;        // re-check products every two weeks
  const KEEP_UNKNOWN_MS = 2 * 24 * 3600 * 1000;  // retry "no ingredient list" sooner
  // Be gentle: shops have bot protection. One product at a time, with a pause between,
  // and only products near the screen.
  const CONCURRENCY = 1;
  const GAP_MS = 2500;                           // at most ~24 products a minute
  const NEAR_SCREENS = 1;
  const BLOCK_PAUSE_MS = 30 * 60 * 1000;         // if the shop pushes back, stop for 30 minutes…
  const PAUSE_KEY = 'vh-paused-until';           // …on every page of the shop, not just this one
  const CHECK_KEY = 'vh-check-url';

  const COLORS = {
    vegan: ['#DDF3D0', '#1F4F12'],
    not: ['#FBDCD5', '#85200F'],
    unsure: ['#FDF0C4', '#5E4300'],
    unknown: ['#ECECE8', '#3F4046'],
    checking: ['#F4F4F0', '#5A5B61']
  };

  // Starts by showing everything (non-vegan faded and labelled); hiding is a switch you turn on.
  const settings = { enabled: true, hideNot: false, hideUnsure: false, collapsed: false };
  let cache = {};                 // "<site>:<key>" -> { facts, at }
  const memo = new Map();         // key -> verdict
  const tiles = new Map();        // key -> Set of tile elements
  const hrefs = new Map();        // key -> product URL
  const queue = [];
  const pending = new Set();
  const failed = new Set();
  let active = 0;
  let pausedUntil = 0;
  let checkUrl = '';               // where the shop's "are you human" check shows up
  let currentKey = null;
  let lastHref = location.href;

  const ck = (key) => `${site.id}:${key}`;
  const isCart = () => site.cartPage.test(location.pathname);
  const isProductPage = () => site.productPage.test(location.pathname);

  // ---------- storage ----------

  function safe(fn) {
    try { return fn(); } catch (e) { log('extension context lost', e); return undefined; }
  }

  async function loadState() {
    const [s, c] = await Promise.all([
      chrome.storage.sync.get(['enabled', 'hideNot', 'hideUnsure', 'collapsed']),
      chrome.storage.local.get([CACHE_KEY, PAUSE_KEY, CHECK_KEY])
    ]);
    for (const k of Object.keys(settings)) if (typeof s[k] === 'boolean') settings[k] = s[k];
    pausedUntil = Number(c[PAUSE_KEY]) || 0;
    checkUrl = c[CHECK_KEY] || '';
    if (Date.now() < pausedUntil) setTimeout(pump, pausedUntil - Date.now() + 1000);
    cache = c[CACHE_KEY] || {};
    const now = Date.now();
    for (const [k, entry] of Object.entries(cache)) {
      const unknown = !entry.facts || !(entry.facts.ingredients || entry.facts.offIngredients || entry.facts.offTags);
      // v0.2 didn't record categories; look those "no ingredient list" products up again.
      // Older versions didn't keep categories or descriptions: look those products up again
      // (only the ones that could change: unknown, or unsure without a description)
      const unsureNoDesc = entry.facts && !('description' in entry.facts) && VH.classifyProduct(entry.facts).status === 'unsure';
      const stale = (unknown && entry.facts && !('category' in entry.facts)) || unsureNoDesc;
      if (stale || !entry.at || now - entry.at > (unknown ? KEEP_UNKNOWN_MS : KEEP_MS)) delete cache[k];
    }
  }

  let saveTimer = null;
  function saveCache() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => safe(() => chrome.storage.local.set({ [CACHE_KEY]: cache }).catch(() => {})), 800);
  }

  function saveSetting(k, v) {
    settings[k] = v;
    safe(() => chrome.storage.sync.set({ [k]: v }).catch(() => {}));
  }

  function verdictFor(key) {
    if (memo.has(key)) return memo.get(key);
    const entry = cache[ck(key)];
    if (!entry) return null;
    const v = VH.classifyProduct(entry.facts);
    memo.set(key, v);
    return v;
  }

  function remember(key, facts) {
    cache[ck(key)] = { facts, at: Date.now() };
    memo.delete(key);
    saveCache();
  }

  // ---------- looking products up ----------

  function mergeFacts(into, from) {
    if (!from) return into;
    for (const k of ['ingredients', 'ean', 'name', 'category', 'brand', 'description']) if (!into[k] && from[k]) into[k] = from[k];
    if (from.claimVegan) into.claimVegan = true;
    return into;
  }

  function nameFromTiles(key) {
    const set = tiles.get(key);
    if (!set) return '';
    for (const t of set) {
      for (const el of t.querySelectorAll('h2,h3,h4,[data-test*="name"],[class*="name" i],[class*="title" i],a')) {
        if (el.closest('[data-vh-ui]')) continue;
        const txt = (el.textContent || '').trim();
        if (txt.length > 2 && txt.length < 140) return txt;
      }
      const img = t.querySelector('img[alt]');
      if (img && img.alt.trim()) return img.alt.trim();
    }
    return '';
  }

  class Blocked extends Error {
    constructor(message, url) { super(message); this.url = url; }
  }

  // The shop's bot protection answers with a challenge instead of data.
  function checkBlocked(res, wantJson, url) {
    const type = res.headers.get('content-type') || '';
    if ([202, 403, 405, 429].includes(res.status)) throw new Blocked('HTTP ' + res.status, url);
    if (wantJson && res.ok && type.includes('html')) throw new Blocked('got a web page instead of data', url);
  }

  async function lookup(key) {
    const facts = { ingredients: '', ean: null, name: '', claimVegan: false, category: null };
    let answered = false;

    // Coop: ask Open Food Facts by barcode, not the shop
    if (site.lookup === 'openfoodfacts') {
      const off = await safe(() => chrome.runtime.sendMessage({ type: 'vh:off', ean: key }).catch(() => null));
      if (!off || (!off.ok && off.status !== 404)) throw new Error('Open Food Facts did not answer');
      Object.assign(facts, lightFacts(key), { ean: key });
      if (off.ok) {
        facts.offIngredients = off.ingredients || '';
        facts.offTags = off.tags || [];
        if (off.claimVegan) facts.claimVegan = true;
        if (!facts.name) facts.name = off.name || '';
      }
      return facts;
    }

    for (const url of site.apiUrls(site.store(location.pathname), key)) {
      try {
        const res = await fetch(url, {
          credentials: 'include',
          headers: { accept: 'application/json', 'ecom-request-source': 'web' }
        });
        checkBlocked(res, true, url);
        if (!res.ok || !(res.headers.get('content-type') || '').includes('json')) continue;
        answered = true;
        mergeFacts(facts, VH.factsFromJson(await res.json()));
        break; // the shop answered: if there's no list, the product page won't have one either
      } catch (e) {
        if (e instanceof Blocked) throw e;
        log('api', url, e.message);
      }
    }

    const href = hrefs.get(key);
    if (!answered && href) {
      try {
        const res = await fetch(href, { credentials: 'include' });
        checkBlocked(res, false, href);
        if (res.ok) {
          const html = await res.text();
          if (/human verification|confirm you are human|captcha/i.test(html.slice(0, 4000))) throw new Blocked('verification page', href);
          answered = true;
          mergeFacts(facts, VH.factsFromHtml(html, key));
        }
      } catch (e) {
        if (e instanceof Blocked) throw e;
        log('page', href, e.message);
      }
    }

    if (!facts.ingredients && facts.ean) {
      const off = await safe(() => chrome.runtime.sendMessage({ type: 'vh:off', ean: facts.ean }).catch(() => null));
      if (off && off.ok) {
        facts.offIngredients = off.ingredients || '';
        facts.offTags = off.tags || [];
        if (off.claimVegan) facts.claimVegan = true;
        if (!facts.name) facts.name = off.name || '';
      }
    }

    // The name people see on the tile is more reliable than a name dug out of JSON.
    facts.name = nameFromTiles(key) || facts.name;
    if (!answered) throw new Error('shop did not answer');
    return facts;
  }

  function distanceFromView(key) {
    const set = tiles.get(key);
    let best = Infinity;
    if (set) for (const t of set) {
      const r = t.getBoundingClientRect();
      const d = r.bottom < 0 ? -r.bottom : r.top > innerHeight ? r.top - innerHeight : 0;
      best = Math.min(best, d);
    }
    return best;
  }

  // ---------- data the shop's own page already loaded (no extra requests) ----------

  const light = new Map();        // key -> { name, brand, category } seen in the shop's own data

  function lightFacts(key) {
    const f = Object.assign({}, light.get(key) || {});
    if (!f.name) f.name = nameFromTiles(key);
    if (!f.category && site.categoryFromHref && hrefs.get(key)) {
      try { f.category = site.categoryFromHref(hrefs.get(key)); } catch (e) { /* ignore */ }
    }
    return f;
  }

  // Name, brand and category are often enough: fruit & veg, non-food, plant-only brands,
  // "Vegan" in the name, "Kycklingfilé"… Those never need a request.
  function decideWithoutAsking(key) {
    if (cache[ck(key)]) return true;
    const f = lightFacts(key);
    if (!f.name) return false;
    const v = VH.classifyProduct(f);
    if (v.status === 'vegan' || v.status === 'not' || v.status === 'skip') {
      remember(key, f);
      return true;
    }
    return false;
  }

  function absorbShopData(url, data) {
    const seen = new Set();
    (function walk(v, depth) {
      if (!v || typeof v !== 'object' || depth > 14 || seen.has(v)) return;
      seen.add(v);
      if (Array.isArray(v)) { v.forEach((x) => walk(x, depth + 1)); return; }
      // ICA: retailerProductId · Willys/Hemköp: code "101773952_ST" · Coop: ean
      const id = v.retailerProductId != null ? v.retailerProductId
        : (typeof v.code === 'string' && /^\d+_[A-Z]{1,4}$/.test(v.code)) ? v.code
        : (v.ean != null && /^\d{8,14}$/.test(String(v.ean))) ? v.ean : null;
      if (id != null && typeof v.name === 'string') {
        const key = String(id);
        const f = light.get(key) || {};
        if (!f.name) f.name = v.name;
        const brand = [v.brand, v.manufacturer, v.manufacturerName].find((x) => typeof x === 'string');
        if (!f.brand && brand) f.brand = brand;
        if (!f.category && Array.isArray(v.categoryPath)) f.category = v.categoryPath.filter((x) => typeof x === 'string');
        light.set(key, f);
        // Some shops send the full details, ingredients included, along with the list
        if (!cache[ck(key)] || !cache[ck(key)].facts.ingredients) {
          const full = VH.factsFromJson(v);
          if (full.ingredients) remember(key, Object.assign(lightFacts(key), full));
        }
      }
      for (const val of Object.values(v)) walk(val, depth + 1);
    })(data, 0);

    // Opening a product makes the shop load its full details: keep the ingredient list.
    const id = data && data.product && data.product.retailerProductId;
    if (id != null && /\/products\/bop/.test(url)) {
      const facts = VH.factsFromJson(data);
      if (facts.ingredients) remember(String(id), Object.assign(lightFacts(String(id)), facts));
    }

    for (let i = queue.length - 1; i >= 0; i--) {
      const key = queue[i];
      if (decideWithoutAsking(key)) { queue.splice(i, 1); pending.delete(key); }
    }
    applyAll();
    renderBar();
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.source !== 'vegan-helper-hook') return;
    try { absorbShopData(e.data.url, e.data.data); } catch (err) { log('could not read shop data', err); }
  });

  function enqueue(key) {
    if (pending.has(key) || failed.has(key) || cache[ck(key)]) return;
    if (decideWithoutAsking(key)) return;
    pending.add(key);
    queue.push(key);
    pump();
  }

  function pump() {
    if (Date.now() < pausedUntil) return;
    while (active < CONCURRENCY && queue.length) {
      // Check what's on screen first, and leave far-away products until you scroll to them.
      let pick = -1, best = Infinity;
      for (let i = 0; i < queue.length; i++) {
        const d = distanceFromView(queue[i]);
        if (d < best) { best = d; pick = i; if (d === 0) break; }
      }
      if (pick < 0 || best > innerHeight * NEAR_SCREENS) return;
      const key = queue.splice(pick, 1)[0];
      active++;
      lookup(key)
        .then((facts) => { pending.delete(key); remember(key, facts); })
        .catch((e) => {
          if (e instanceof Blocked) {
            // Back off completely; the product goes back in the queue for later.
            pausedUntil = Date.now() + BLOCK_PAUSE_MS;
            checkUrl = e.url ? new URL(e.url, location.href).href : location.href;
            safe(() => chrome.storage.local.set({ [PAUSE_KEY]: pausedUntil, [CHECK_KEY]: checkUrl }).catch(() => {}));
            queue.unshift(key);
            log('the shop asked us to slow down; pausing', e.message);
            setTimeout(pump, BLOCK_PAUSE_MS + 1000);
          } else {
            pending.delete(key);
            failed.add(key);
            log('could not check', key, e.message);
          }
        })
        .finally(() => {
          active--;
          applyKey(key);
          renderBar();
          setTimeout(pump, GAP_MS);
        });
    }
  }

  let scrollTimer = null;
  addEventListener('scroll', () => {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(pump, 250);
  }, { passive: true });

  // ---------- finding products on the page ----------

  function keyOfLink(a) {
    if (!a.href || a.host !== location.host || !site.productLink.test(a.pathname)) return null;
    return VH.productKeyFromHref(a.href, location.href);
  }

  // Climb from a product link to the biggest box that holds only this product.
  function findTile(a, key) {
    let el = a;
    for (let depth = 0; depth < 12; depth++) {
      const p = el.parentElement;
      if (!p || p === document.body || p === document.documentElement) break;
      if (p.matches('main,header,nav,footer,[role="main"],[data-vh-ui]')) break;
      let other = false;
      for (const l of p.querySelectorAll('a[href]')) {
        const k = keyOfLink(l);
        if (k && k !== key) { other = true; break; }
      }
      if (other) break;
      const r = p.getBoundingClientRect();
      if (r.height > 900 || (r.width > innerWidth * 0.95 && r.height > 320)) break;
      el = p;
    }
    return el === a && a.parentElement ? a : el;
  }

  function scan() {
    if (!settings.enabled) return;
    currentKey = isProductPage() ? VH.productKeyFromHref(location.href) : null;

    for (const a of document.querySelectorAll('a[href]')) {
      if (a.closest('[data-vh-ui]')) continue;
      const key = keyOfLink(a);
      if (!key || key === currentKey) continue;
      const known = a.closest('[data-vh-key]');
      if (known && known.dataset.vhKey === key) {
        if (!tiles.has(key)) tiles.set(key, new Set());
        tiles.get(key).add(known);
        if (!hrefs.has(key)) hrefs.set(key, a.href);
        enqueue(key);
        continue;
      }
      const tile = findTile(a, key);
      if (tile.dataset.vhKey && tile.dataset.vhKey !== key) continue;
      tile.dataset.vhKey = key;
      if (!tiles.has(key)) tiles.set(key, new Set());
      tiles.get(key).add(tile);
      if (!hrefs.has(key)) hrefs.set(key, a.href);
      enqueue(key);
    }

    readPageVeganMarks();
    checkCurrentProduct();
    applyAll();
    renderBar();
  }

  // Shops that mark vegan products in the data embedded in the page (Mathem): read those marks
  // for every product on screen, without any request.
  let marksSeenFor = '';
  function readPageVeganMarks() {
    if (!site.pageVeganMarks) return;
    const sig = location.href + '|' + tiles.size;
    if (sig === marksSeenFor) return;
    marksSeenFor = sig;
    let ids;
    try { ids = VH.veganMarkedIds(document.documentElement.innerHTML); } catch (e) { return; }
    for (const id of ids) {
      const f = light.get(id) || {};
      f.claimVegan = true;
      light.set(id, f);
      const entry = cache[ck(id)];
      if (entry && !entry.facts.claimVegan) { entry.facts.claimVegan = true; memo.delete(id); saveCache(); }
    }
    for (let i = queue.length - 1; i >= 0; i--) {
      if (decideWithoutAsking(queue[i])) { pending.delete(queue[i]); queue.splice(i, 1); }
    }
  }

  function checkCurrentProduct() {
    if (!currentKey) return;
    // Reading the screen is only reliable where the shop puts structured data on it (Coop).
    // Elsewhere (Mathem pop-ups, ICA's browse site) use the same targeted product-page reading as listings.
    if (!site.readProductDom) {
      if (!cache[ck(currentKey)]) { hrefs.set(currentKey, location.href); enqueue(currentKey); }
      return;
    }
    const facts = VH.factsFromDom(document);
    if (facts.ingredients) {
      const old = cache[ck(currentKey)];
      if (!old || old.facts.ingredients !== facts.ingredients) remember(currentKey, facts);
    } else if (!cache[ck(currentKey)]) {
      hrefs.set(currentKey, location.href);
      enqueue(currentKey);
    }
  }

  // ---------- badges, hiding, dimming ----------

  function badgeText(v) {
    if (!v) return 'Checking…';
    if (v.status === 'vegan') return 'Vegan';
    if (v.status === 'not') return 'Not vegan · ' + v.reasons.slice(0, 2).join(', ');
    if (v.status === 'unsure') return v.conflict ? 'Unsure · check label' : 'Unsure · ' + v.unsure.slice(0, 2).join(', ');
    return 'No ingredient list';
  }

  function badgeTitle(v) {
    if (!v) return 'Vegan helper is checking this product';
    const from = {
      ingredients: 'Checked against the ingredient list in the shop.',
      openfoodfacts: 'Checked with Open Food Facts (the shop showed no ingredient list).',
      name: 'Judged from the product name; the shop showed no ingredient list.',
      produce: 'Fruit, vegetable or other fresh produce, so there is no ingredient list.',
      category: 'The shop sells this as fish/seafood or meat, and nothing says it is plant-based.',
      'nonfood-known': 'Not food, but usually made with animal materials.',
      label: 'The product is labelled vegan.'
    }[v.source] || 'No ingredient list was found, so this product could not be checked.';
    const lines = [from];
    if (v.reasons.length) lines.push('Animal-derived: ' + v.reasons.join(', '));
    if (v.unsure.length) lines.push(v.conflict ? 'Labelled vegan, but the list mentions: ' + v.unsure.join(', ') : 'Could be animal-derived: ' + v.unsure.join(', '));
    if (v.mayContain) lines.push('Says it may contain traces of other products.');
    return lines.join('\n');
  }

  function rememberStyle(tile, prop) {
    const k = 'vhOrig' + prop[0].toUpperCase() + prop.slice(1);
    if (!(k in tile.dataset)) tile.dataset[k] = tile.style.getPropertyValue(prop) || '';
    return tile.dataset[k];
  }

  function setStyle(tile, prop, value) {
    const orig = rememberStyle(tile, prop);
    if (value == null) {
      if (orig) tile.style.setProperty(prop, orig); else tile.style.removeProperty(prop);
    } else if (tile.style.getPropertyValue(prop) !== value) {
      tile.style.setProperty(prop, value, 'important');
    }
  }

  function applyTile(tile, key) {
    const v = verdictFor(key);
    const status = v ? v.status : failed.has(key) ? 'unknown' : 'checking';

    // Not food and nothing to check: leave the product exactly as the shop shows it.
    if (status === 'skip') {
      tile.querySelectorAll('.vh-badge').forEach((b) => b.remove());
      tile.querySelectorAll('[data-vh-faded]').forEach((el) => { restoreStyles(el); delete el.dataset.vhFaded; });
      setStyle(tile, 'display', null);
      return;
    }

    // Wide, short boxes are rows (the cart): put the badge next to the name instead of over the picture.
    if (!tile.dataset.vhShape) {
      const r = tile.getBoundingClientRect();
      tile.dataset.vhShape = r.width > r.height * 2.2 ? 'row' : 'card';
    }
    const inline = tile.dataset.vhShape === 'row';

    let badge = tile.querySelector('.vh-badge');
    if (badge && badge.closest('[data-vh-key]') !== tile) badge = null;
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'vh-badge';
      badge.setAttribute('data-vh-ui', '');
      const nameLink = inline && [...tile.querySelectorAll('a[href]')].find((a) => (a.textContent || '').trim().length > 2);
      if (nameLink) { nameLink.insertAdjacentElement('afterend', badge); badge.dataset.vhInline = '1'; }
      else {
        if (getComputedStyle(tile).position === 'static') setStyle(tile, 'position', 'relative');
        // Keep the badge inside the product's own layer, so the shop's menus and pop-ups cover it
        if (getComputedStyle(tile).isolation !== 'isolate') setStyle(tile, 'isolation', 'isolate');
        tile.appendChild(badge);
      }
    }
    const text = badgeText(v);
    if (badge.textContent !== text) badge.textContent = text;
    badge.title = badgeTitle(v);
    const [bg, fg] = COLORS[status];
    const place = badge.dataset.vhInline
      ? 'position:relative;display:inline-block;vertical-align:middle;margin:0 8px;max-width:340px;'
      : 'position:absolute;top:8px;left:8px;z-index:1;max-width:calc(100% - 16px);';
    const css = `all:initial;${place}box-sizing:border-box;` +
      `padding:3px 9px;border-radius:999px;background:${bg};color:${fg};` +
      `font:600 12px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;white-space:nowrap;overflow:hidden;` +
      `text-overflow:ellipsis;box-shadow:0 1px 3px rgba(0,0,0,.18);cursor:help;pointer-events:auto;` +
      `opacity:${status === 'checking' ? '0.75' : '1'};`;
    if (badge.dataset.css !== css) { badge.style.cssText = css; badge.dataset.css = css; }

    // In the cart nothing is hidden or faded: the point there is to notice.
    const cart = isCart();
    const hide = !cart && ((status === 'not' && settings.hideNot) || (status === 'unsure' && settings.hideUnsure));
    setStyle(tile, 'display', hide ? 'none' : null);
    // Fade the product but keep its badge fully readable.
    const fade = !cart && !hide && status === 'not';
    for (const child of tile.children) {
      if (child === badge || child.contains(badge)) continue;
      if (fade) { setStyle(child, 'opacity', '0.45'); child.dataset.vhFaded = '1'; }
      else if (child.dataset.vhFaded) { setStyle(child, 'opacity', null); delete child.dataset.vhFaded; }
    }
  }

  function restoreStyles(el) {
    for (const prop of ['display', 'opacity', 'position', 'isolation']) {
      const k = 'vhOrig' + prop[0].toUpperCase() + prop.slice(1);
      if (k in el.dataset) {
        const orig = el.dataset[k];
        if (orig) el.style.setProperty(prop, orig); else el.style.removeProperty(prop);
        delete el.dataset[k];
      }
    }
  }

  function clearTile(tile) {
    tile.querySelectorAll('.vh-badge').forEach((b) => b.remove());
    tile.querySelectorAll('[data-vh-faded]').forEach((el) => { restoreStyles(el); delete el.dataset.vhFaded; });
    restoreStyles(tile);
    delete tile.dataset.vhKey;
    delete tile.dataset.vhShape;
  }

  // Shops re-render product boxes all the time, so always work from what's on the page now.
  function syncTiles() {
    const live = document.querySelectorAll('[data-vh-key]');
    for (const set of tiles.values()) for (const t of set) if (!t.isConnected) set.delete(t);
    for (const t of live) {
      const key = t.dataset.vhKey;
      if (!tiles.has(key)) tiles.set(key, new Set());
      tiles.get(key).add(t);
    }
    for (const [key, set] of tiles) if (!set.size) tiles.delete(key);
  }

  function applyKey(key) {
    for (const t of document.querySelectorAll('[data-vh-key]')) {
      if (t.dataset.vhKey !== key) continue;
      settings.enabled ? applyTile(t, key) : clearTile(t);
    }
  }

  function applyAll() {
    syncTiles();
    for (const t of document.querySelectorAll('[data-vh-key]')) {
      settings.enabled ? applyTile(t, t.dataset.vhKey) : clearTile(t);
    }
  }

  function clearAll() {
    for (const t of document.querySelectorAll('[data-vh-key]')) clearTile(t);
    tiles.clear();
  }

  // ---------- the filter bar ----------

  let host = null, shadow = null;

  const LEAF = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#C8F169" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14z"/><path d="M5 19l7-7"/></svg>';

  const BAR_CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
    .wrap { position: fixed; left: 50%; bottom: 16px; transform: translateX(-50%); z-index: 2147483000;
      max-width: calc(100vw - 32px); display: flex; flex-direction: column; gap: 6px; align-items: center; }
    .bar { background: #16181D; color: #F4F4F0; border-radius: 16px; padding: 8px 8px 8px 14px;
      display: flex; align-items: center; gap: 12px; flex-wrap: wrap; box-shadow: 0 12px 32px rgba(0,0,0,.28); font-size: 14px; }
    .brand { display: flex; align-items: center; gap: 8px; font-weight: 700; white-space: nowrap; }
    .sep { width: 1px; height: 22px; background: #3A3D45; }
    .chips { display: flex; gap: 6px; flex-wrap: wrap; }
    .switch { display: flex; align-items: center; gap: 10px; min-height: 40px; padding: 0 6px; border: none; background: transparent; color: #F4F4F0; font-size: 14px; border-radius: 10px; }
    .track { position: relative; width: 40px; height: 24px; border-radius: 999px; background: #3A3D45; transition: background .15s; flex-shrink: 0; }
    .thumb { position: absolute; top: 3px; left: 3px; width: 18px; height: 18px; border-radius: 50%; background: #F4F4F0; transition: transform .15s; }
    .switch[aria-checked="true"] .track { background: #C8F169; }
    .switch[aria-checked="true"] .thumb { transform: translateX(16px); background: #16181D; }
    .switch:focus-visible { outline: 2px solid #C8F169; outline-offset: 2px; }
    .action { height: 36px; padding: 0 14px; border-radius: 999px; border: none; background: #C8F169; color: #16181D; font-weight: 700; font-size: 14px; }
    .action.resume { background: transparent; color: #F4F4F0; border: 1px solid #5A5E68; }
    .action:focus-visible { outline: 2px solid #C8F169; outline-offset: 2px; }
    button { font: inherit; cursor: pointer; }
    .chip { height: 36px; padding: 0 14px; border-radius: 999px; border: 1px solid #5A5E68; background: transparent; color: #F4F4F0; font-size: 14px; }
    .chip[aria-pressed="true"] { background: #C8F169; border-color: #C8F169; color: #16181D; font-weight: 600; }
    .chip:focus-visible, .icon:focus-visible, .fab:focus-visible { outline: 2px solid #C8F169; outline-offset: 2px; }
    .status { color: #C9CBD1; font-size: 13px; white-space: nowrap; }
    .status b { color: #F4F4F0; }
    .icon { width: 36px; height: 36px; border-radius: 10px; border: none; background: #262931; color: #F4F4F0; display: flex; align-items: center; justify-content: center; font-size: 18px; }
    .product { background: #16181D; color: #F4F4F0; border-radius: 12px; padding: 8px 14px; font-size: 14px; box-shadow: 0 8px 24px rgba(0,0,0,.25); max-width: 640px; }
    .pill { display: inline-block; padding: 2px 9px; border-radius: 999px; font-weight: 700; font-size: 13px; margin-right: 6px; }
    .fab { height: 44px; padding: 0 14px; border-radius: 999px; border: none; background: #16181D; color: #F4F4F0; display: flex; align-items: center; gap: 8px; box-shadow: 0 8px 24px rgba(0,0,0,.28); font-weight: 600; font-size: 14px; }
    [hidden] { display: none !important; }
  `;

  function ensureBar() {
    if (host && host.isConnected) return;
    host = document.createElement('div');
    host.setAttribute('data-vh-ui', '');
    shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>${BAR_CSS}</style>
      <div class="wrap">
        <div class="product" hidden></div>
        <div class="bar" role="region" aria-label="Vegan helper">
          <span class="brand">${LEAF}Vegan helper</span>
          <span class="sep"></span>
          <div class="chips">
            <button class="switch" data-k="hideNot" type="button" role="switch" aria-checked="false"><span class="track"><span class="thumb"></span></span>Hide non-vegan</button>
            <button class="switch" data-k="hideUnsure" type="button" role="switch" aria-checked="false"><span class="track"><span class="thumb"></span></span>Hide unsure</button>
          </div>
          <span class="status" aria-live="polite"></span>
          <button class="action check" type="button" hidden>Do the check</button>
          <button class="action resume" type="button" hidden>Resume</button>
          <button class="icon min" type="button" aria-label="Minimise vegan helper">–</button>
        </div>
        <button class="fab" type="button" hidden aria-label="Open vegan helper">${LEAF}<span class="fab-text"></span></button>
      </div>`;
    shadow.querySelectorAll('.switch').forEach((b) => b.addEventListener('click', () => {
      saveSetting(b.dataset.k, !settings[b.dataset.k]);
      applyAll();
      renderBar();
    }));
    shadow.querySelector('.check').addEventListener('click', () => {
      // The shop shows its own "are you human" check on that page; you do it, we don't.
      window.open(checkUrl || location.href, '_blank', 'noopener');
    });
    shadow.querySelector('.resume').addEventListener('click', () => {
      pausedUntil = 0;
      safe(() => chrome.storage.local.set({ [PAUSE_KEY]: 0 }).catch(() => {}));
      renderBar();
      pump();
    });
    shadow.querySelector('.min').addEventListener('click', () => { saveSetting('collapsed', true); renderBar(); });
    shadow.querySelector('.fab').addEventListener('click', () => { saveSetting('collapsed', false); renderBar(); });
    document.documentElement.appendChild(host);
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function renderBar() {
    if (!settings.enabled) { host?.remove(); host = null; return; }
    syncTiles();
    const keys = [...tiles.keys()];
    if (!keys.length && !currentKey) { host?.remove(); host = null; return; }
    ensureBar();

    const counts = { vegan: 0, not: 0, unsure: 0, unknown: 0, checking: 0, skip: 0 };
    let hidden = 0;
    const notNames = [];
    for (const key of keys) {
      const v = verdictFor(key);
      const s = v ? v.status : failed.has(key) ? 'unknown' : 'checking';
      counts[s]++;
      if (s === 'skip') continue;
      if (!isCart() && ((s === 'not' && settings.hideNot) || (s === 'unsure' && settings.hideUnsure))) hidden++;
      if (s === 'not') notNames.push(cache[ck(key)]?.facts?.name || '');
    }
    // Non-food products without an ingredient list don't count either way.
    keys.splice(0, keys.length, ...keys.filter((k) => verdictFor(k)?.status !== 'skip'));
    const checked = keys.length - counts.checking;

    const bar = shadow.querySelector('.bar');
    const fab = shadow.querySelector('.fab');
    // On a product page with no other products around, the verdict card is enough.
    bar.hidden = settings.collapsed || !keys.length;
    fab.hidden = !settings.collapsed;

    const chips = shadow.querySelector('.chips');
    chips.hidden = isCart() || !keys.length;
    shadow.querySelector('.sep').hidden = chips.hidden;
    shadow.querySelectorAll('.switch').forEach((b) => b.setAttribute('aria-checked', String(settings[b.dataset.k])));

    let status;
    if (isCart()) {
      status = !keys.length ? ''
        : counts.not ? `<b>${counts.not} of ${keys.length} items aren't vegan</b>`
        : counts.checking ? `Checking ${checked} of ${keys.length}…`
        : `<b>Everything in your cart looks vegan</b>${counts.unsure + counts.unknown ? ` · ${counts.unsure + counts.unknown} to double-check` : ''}`;
      if (counts.not && counts.checking) status += ` · checking ${counts.checking} more…`;
    } else {
      const parts = [];
      if (hidden) parts.push(`<b>${hidden} hidden</b>`);
      if (counts.checking) parts.push(`checking ${checked} of ${keys.length}…`);
      else if (keys.length) parts.push(`${keys.length} checked`);
      status = parts.join(' · ');
    }
    const paused = Date.now() < pausedUntil && counts.checking > 0;
    if (paused) {
      status = `<b>${escapeHtml(site.name)} wants to check you're human.</b> Do the check, then resume`;
    }
    shadow.querySelector('.check').hidden = !paused;
    shadow.querySelector('.resume').hidden = !paused;
    const statusEl = shadow.querySelector('.status');
    if (statusEl.innerHTML !== status) statusEl.innerHTML = status;
    statusEl.title = isCart() && notNames.length ? 'Not vegan: ' + notNames.filter(Boolean).join(', ') : '';
    shadow.querySelector('.fab-text').textContent = isCart() ? (counts.not ? `${counts.not} not vegan` : 'Cart OK') : (hidden ? `${hidden} hidden` : 'Vegan helper');

    // The product you're looking at
    const productEl = shadow.querySelector('.product');
    const v = currentKey ? verdictFor(currentKey) : null;
    if (currentKey && !settings.collapsed && !(v && v.status === 'skip')) {
      const status = v ? v.status : 'checking';
      const [bg, fg] = COLORS[status];
      const label = { vegan: 'Vegan', not: 'Not vegan', unsure: 'Unsure', unknown: 'Not checked', checking: 'Checking…' }[status];
      let detail = '';
      if (v && v.status === 'not') detail = 'Contains ' + v.reasons.slice(0, 4).join(', ');
      else if (v && v.status === 'unsure') detail = (v.conflict ? 'Labelled vegan, but mentions ' : 'Could be animal-derived: ') + v.unsure.slice(0, 4).join(', ');
      else if (v && v.status === 'vegan') detail = v.source === 'label' ? 'Labelled vegan' : 'Nothing animal-derived in the ingredients' + (v.mayContain ? ' (may contain traces)' : '');
      else if (v) detail = 'No ingredient list found on this page';
      const html = `<span class="pill" style="background:${bg};color:${fg}">${label}</span>${escapeHtml(detail)}`;
      if (productEl.innerHTML !== html) productEl.innerHTML = html;
      productEl.title = v ? badgeTitle(v) : '';
      productEl.hidden = false;
    } else {
      productEl.hidden = true;
    }
  }

  // ---------- keeping up with the page ----------

  let scanTimer = null;
  function scheduleScan(delay = 350) {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, delay);
  }

  function isOurs(node) {
    return node.nodeType !== 1 || (node.matches && node.matches('[data-vh-ui]'));
  }

  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const n of m.addedNodes) if (!isOurs(n)) return scheduleScan();
      for (const n of m.removedNodes) if (!isOurs(n)) return scheduleScan();
    }
  });

  function onSettingsChanged(changes, area) {
    if (area === 'local' && changes[PAUSE_KEY]) {
      // Another ICA tab hit the limit: pause here too.
      pausedUntil = Number(changes[PAUSE_KEY].newValue) || 0;
      if (changes[CHECK_KEY]) checkUrl = changes[CHECK_KEY].newValue || '';
      if (!pausedUntil) pump(); // resumed from another tab
      renderBar();
    }
    if (area === 'sync') {
      let touched = false;
      for (const k of Object.keys(settings)) {
        if (changes[k] && typeof changes[k].newValue === 'boolean') { settings[k] = changes[k].newValue; touched = true; }
      }
      if (!touched) return;
      if (!settings.enabled) { clearAll(); renderBar(); } else scan();
    }
    if (area === 'local' && changes[CACHE_KEY] && !changes[CACHE_KEY].newValue) {
      // "Re-check everything" from the popup
      cache = {}; memo.clear(); failed.clear();
      for (const key of tiles.keys()) enqueue(key);
      if (currentKey) enqueue(currentKey);
      applyAll(); renderBar();
    }
  }

  // For troubleshooting from the console (only visible to the extension's own scripts).
  window.__vhDebug = () => ({
    site: site.id,
    products: [...tiles.keys()].map((key) => {
      const v = verdictFor(key);
      return { key, tiles: tiles.get(key).size, status: v ? v.status : failed.has(key) ? 'failed' : 'checking', why: v ? [...v.reasons, ...v.unsure] : [], name: cache[ck(key)]?.facts?.name || '' };
    })
  });

  async function start() {
    try { await loadState(); } catch (e) { log('could not load settings', e); }
    chrome.storage.onChanged.addListener(onSettingsChanged);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    // The shop is a single-page app: notice when the address changes.
    setInterval(() => {
      if (location.href !== lastHref) { lastHref = location.href; currentKey = null; scheduleScan(200); }
      else if (settings.enabled) applyAll(); // put back styles the page may have reset
    }, 1000);
    scan();
    // Product details often appear a moment after the page loads.
    setTimeout(scan, 1500);
  }

  start();
})();
