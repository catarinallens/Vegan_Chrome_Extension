/*
 * Vegan Helper: runs inside the shop's own page (not the extension's sandbox).
 * It only *listens*: when the shop's page loads product data for itself, a copy is
 * passed to the extension. It never sends requests of its own.
 */
(function () {
  'use strict';
  if (window.__vhHook) return;
  window.__vhHook = true;

  // ICA (Ocado platform), Willys/Hemköp (Axfood) and Coop's own product data requests
  const WATCH = /\/api\/webproductpagews\/|\/axfood\/rest\/|external\.api\.coop\.se\/personalization\/search\//;

  function share(url, data) {
    try { window.postMessage({ source: 'vegan-helper-hook', url: String(url), data }, location.origin); } catch (e) { /* too big or not cloneable */ }
  }

  // fetch()
  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input, init) {
      const p = origFetch.apply(this, arguments);
      try {
        const url = typeof input === 'string' ? input : input && input.url;
        if (url && WATCH.test(url)) {
          p.then((res) => {
            if (res.ok && (res.headers.get('content-type') || '').includes('json')) {
              res.clone().json().then((data) => share(url, data)).catch(() => {});
            }
          }).catch(() => {});
        }
      } catch (e) { /* never break the shop */ }
      return p;
    };
  }

  // XMLHttpRequest (used by some shop code)
  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    try {
      if (url && WATCH.test(String(url))) {
        this.addEventListener('load', () => {
          try {
            if (this.status >= 200 && this.status < 300 && /json/.test(this.getResponseHeader('content-type') || '')) {
              share(url, typeof this.response === 'object' && this.response ? this.response : JSON.parse(this.responseText));
            }
          } catch (e) { /* ignore */ }
        });
      }
    } catch (e) { /* ignore */ }
    return origOpen.apply(this, arguments);
  };

  // Products that came with the first page load
  function shareInitial() {
    if (window.__INITIAL_STATE__) share('initial-state', JSON.parse(JSON.stringify(window.__INITIAL_STATE__)));
  }
  // The extension's script starts after the page has loaded, so it asks for this when ready.
  window.addEventListener('message', (e) => {
    if (e.source === window && e.data && e.data.source === 'vegan-helper' && e.data.type === 'want-initial') shareInitial();
  });
})();
