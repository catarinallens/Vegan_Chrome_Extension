/*
 * Vegan Helper: one entry per supported shop.
 * Adding Mathem or Willys later means adding an entry here.
 */
(function (root) {
  'use strict';

  const SITES = [
    {
      id: 'ica',
      name: 'ICA',
      hosts: ['handlaprivatkund.ica.se'],
      // Links to a product look like /stores/1004599/products/<slug>/<id>
      productLink: /\/products\//,
      productPage: /\/products\/[^/]+/,
      cartPage: /\/(?:cart|varukorg|basket|checkout|kassa)(?:\/|$)/i,
      store: (path) => (path.match(/\/stores\/(\d+)/) || [])[1] || null,
      // JSON with the full product details (ICA's shop runs on the Ocado platform).
      apiUrls: (store, id) => [
        store && `/stores/${store}/api/webproductpagews/v5/products/bop?retailerProductId=${encodeURIComponent(id)}`,
        `/api/webproductpagews/v5/products/bop?retailerProductId=${encodeURIComponent(id)}`
      ].filter(Boolean)
    },
    {
      id: 'ica-handla',
      name: 'ICA',
      hosts: ['handla.ica.se'],
      // ICA's browse site: /produkt/1203222, product pages are plain HTML with an "Ingredienser" section
      productLink: /\/produkt\/\d+/,
      productPage: /\/produkt\/\d+/,
      cartPage: /\/(?:varukorg|kassa|cart|checkout)(?:\/|$)/i,
      store: () => null,
      apiUrls: () => []
    },
    {
      id: 'mathem',
      name: 'Mathem',
      hosts: ['www.mathem.se', 'mathem.se'],
      // /se/products/66111-marabou-mjolkchoklad/ ; product pages are plain HTML with "Ingredienser"
      productLink: /\/products\/\d+-[^/]+/,
      productPage: /\/products\/\d+-[^/]+\/?$/,
      pageVeganMarks: true, // Mathem's own "Veganskt" marking is in the page data
      cartPage: /\/(?:cart|kassa|checkout|varukorg)(?:\/|$)/i,
      store: () => null,
      apiUrls: () => []
    },
    // Willys and Hemköp run on the same Axfood shop platform.
    ...[['willys', 'Willys', 'www.willys.se'], ['hemkop', 'Hemköp', 'www.hemkop.se']].map(([id, name, host]) => ({
      id,
      name,
      hosts: [host, host.replace(/^www\./, '')],
      // /produkt/Mjolkchoklad-Chokladkaka-101773952_ST
      productLink: /\/produkt\/[^/]*\d+_[A-Z]+\/?$/,
      productPage: /\/produkt\/[^/]*\d+_[A-Z]+\/?$/,
      cartPage: /\/(?:varukorg|kassa|checkout|cart)(?:\/|$)/i,
      store: () => null,
      // Axfood's product data: ingredients, manufacturer, breadcrumbs and barcode in one answer
      apiUrls: (store, code) => [`/axfood/rest/p/${encodeURIComponent(code)}`]
    })),
    {
      id: 'coop',
      name: 'Coop',
      hosts: ['www.coop.se', 'coop.se'],
      // /handla/varor/godis-glass-snacks/choklad/ljusa-chokladkakor/mjolkchoklad-7622202238475
      productLink: /\/handla\/varor\/.+-\d{8,14}\/?$/,
      productPage: /\/handla\/varor\/.+-\d{8,14}\/?$/,
      cartPage: /\/(?:varukorg|kassa|checkout|cart)(?:\/|$)/i,
      store: () => null,
      apiUrls: () => [],
      // Coop's product pages are built in the browser, so their HTML has no ingredients.
      // The barcode is in the link, so look it up on Open Food Facts instead of asking Coop.
      lookup: 'openfoodfacts',
      // Coop's product pages carry structured product data (with ingredients) once loaded
      readProductDom: true,
      categoryFromHref: (href) => {
        const parts = new URL(href, 'https://www.coop.se').pathname.split('/').filter(Boolean);
        const top = parts[parts.indexOf('varor') + 1] || '';
        const names = {
          'frukt-gronsaker': 'Frukt & grönsaker', 'hushall': 'Hushåll', 'skonhet-hygien': 'Skönhet & hygien',
          'fritid': 'Fritid', 'hem-inredning': 'Hem & inredning', 'djurmat-tillbehor': 'Djur',
          'apotek-halsa-tillskott': 'Apotek, hälsa & tillskott', 'kiosk-tidningar': 'Kiosk & tidningar',
          'fisk-skaldjur': 'Fisk & skaldjur', 'kott-fagel-chark': 'Kött, fågel & chark'
        };
        return top ? [names[top] || top.replace(/-/g, ' ')] : null;
      }
    }
  ];

  function siteFor(host) {
    return SITES.find((s) => s.hosts.includes(host)) || null;
  }

  const api = { SITES, siteFor };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.VH = Object.assign(root.VH || {}, api);
})(typeof globalThis !== 'undefined' ? globalThis : this);
