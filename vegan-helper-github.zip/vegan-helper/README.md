# Vegan helper

A Chrome extension that checks groceries for you while you shop online in Sweden. It reads each product's ingredient list and labels it **Vegan**, **Not vegan** or **Unsure**, with the reason. You can also hide what isn't vegan.

Works on **ICA**, **Mathem**, **Willys**, **Hemköp** and **Coop**.

## What it does

- **Search and category pages:** every product gets a small badge, e.g. *Not vegan · vasslepulver* or *Unsure · E471*. Hover over it to see why.
- **Two switches** in the bar at the bottom: **Hide non-vegan** and **Hide unsure**. With both off, nothing is hidden: non-vegan products are faded and labelled.
- **Product pages:** a small card shows the verdict and the problem ingredients.
- **Cart:** nothing is hidden. Each item gets a badge next to its name, and the bar says how many items aren't vegan.

## Install

The extension isn't in the Chrome Web Store yet, so you load it yourself (takes a minute):

1. Download this repository (green **Code** button → **Download ZIP**) and unzip it.
2. In Chrome, go to `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose the unzipped folder, the one that contains `manifest.json`.
4. Open one of the shops and search for something.

## How it decides

In order, it uses:

1. **The shop's own vegan marking**, where there is one (Mathem's "Veganskt"), and statements like *"lämplig för veganer"* or *"egnet for veganere"* in the ingredients or description.
2. **The ingredient list**, checked against Swedish, Danish/Norwegian and English words for animal ingredients (milk, whey, egg, gelatin, honey, fish species, roe, meat cuts, carmine, shellac and more) and E-numbers.
3. **Open Food Facts**, by barcode, when the shop shows no list (used for Coop).
4. **Name and category** when there's no list at all: fruit and veg count as vegan, non-food gets no badge, and names like *Kycklingfilé* or *Räkor* count as not vegan.

Rules that keep it honest:

- *"Kan innehålla spår av…"* (may contain traces) doesn't count as non-vegan.
- Additives that can be plant or animal (E471, E422, vitamin D3, "smörarom") are **Unsure**, unless the list says they're plant-derived (*"vegetabiliskt emulgeringsmedel (E471)"*).
- Look-alikes are handled: *kakaosmör* (cocoa butter), *kokosmjölk*, *yoghurtkultur*, *fruktkött*, *hjorthornssalt*, *laktosfri*, *tångkaviar*, *rom* as rum in sweets…
- Products sold under **Fisk & skaldjur** or **Kött, chark & fågel** are never called vegan, unless they're labelled vegan or list a plant protein.
- Known plant-only brands (Oatly, Alpro, Oumph!, Planti, Naturli' and others) count as vegan for "unsure" additives.
- Some non-food is flagged too: matches (gelatin), beeswax, wool, leather, silk, down; stearin candles are Unsure.
- When it can't tell, it says so instead of guessing.

## Being gentle with the shops

The extension reads what the shop's page has already loaded first, so many products need no extra request. Everything else is checked one product every few seconds, only for products on your screen. If a shop asks you to prove you're human, the extension pauses and asks *you* to do the shop's own check (**Do the check**, then **Resume**). It never tries to get around it.

Results are remembered for two weeks. **Re-check everything** in the popup clears them.

## Limitations

- Verdicts are only as good as the shop's data and the word lists. Always check the packaging if it matters to you, and please report mistakes.
- Shops change their websites. When one does, that shop may stop working until the extension is updated.
- Coop's listings depend on Open Food Facts, which doesn't know every Swedish product.

## Project structure

| File | What it does |
| --- | --- |
| `manifest.json` | Chrome extension settings and permissions |
| `src/verdict.js` | The ingredient checker: word lists and rules |
| `src/extract.js` | Reads ingredients, brand, category and labels from shop data and pages |
| `src/sites.js` | One entry per shop (links, cart pages, where product data lives) |
| `src/content.js` | Finds products on the page, adds badges, the bar and the cart check |
| `src/page-hook.js` | Listens to product data the shop's own page loads (sends no requests) |
| `src/background.js` | Open Food Facts lookups |
| `popup/` | The popup behind the toolbar icon |
| `test/` | Tests (see below) |

## Development

Tests need [Node.js](https://nodejs.org) 20 or newer.

```bash
npm test        # ingredient checker and data-reading tests
npm run e2e     # loads the extension in Chromium against a fake shop (needs Playwright)
```

Found a wrong verdict? Each fix is added as a test in `test/verdict.test.js`, so the same mistake can't come back. Issues and pull requests are welcome.

## Licence

[MIT](LICENSE) © 2026 Catarina Allen
